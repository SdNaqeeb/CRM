"""
Activity tracking service.
Queries GapAnalysis, HomeworkSubmission, Exam, ClassworkSubmission, StudentResult
to build student and teacher activity feeds.
"""
from datetime import datetime, timedelta, timezone
from collections import defaultdict
from sqlalchemy.orm import Session
from sqlalchemy import func, cast, Date

from models.django_tables import (
    Student, GapAnalysis, Exam, StudentResult,
    Homework, HomeworkSubmission, ClassworkSubmission,
)
from schemas.activity import (
    ActivityEntry, DailyActivitySummary, UserActivityTimeline, ActivityOverview,
)


def _iso(dt: datetime | None) -> str:
    return dt.isoformat() if dt else ""


def get_student_activity_entries(student_id: int, db: Session, days: int = 30) -> list[ActivityEntry]:
    """Get all activity entries for a single student within the last N days."""
    since = datetime.now(timezone.utc) - timedelta(days=days)
    entries: list[ActivityEntry] = []

    student = db.query(Student).filter(Student.id == student_id).first()
    name = student.fullname or "" if student else ""

    # GapAnalysis submissions
    ga_rows = (
        db.query(GapAnalysis)
        .filter(GapAnalysis.student_id == student_id, GapAnalysis.date >= since)
        .order_by(GapAnalysis.date.desc())
        .all()
    )
    for g in ga_rows:
        entries.append(ActivityEntry(
            id=g.id,
            user_id=student_id,
            user_name=name,
            activity_type="gap_analysis",
            title=f"{g.subject or 'Unknown'} - Ch {g.chapter_number or '?'}",
            subject=g.subject,
            score=g.student_score,
            max_score=g.max_marks,
            percentage=g.percentage,
            timestamp=_iso(g.date),
            role="student",
        ))

    # HomeworkSubmission
    hw_rows = (
        db.query(HomeworkSubmission)
        .filter(HomeworkSubmission.student_name_id == student_id, HomeworkSubmission.submission_date >= since)
        .order_by(HomeworkSubmission.submission_date.desc())
        .all()
    )
    for h in hw_rows:
        entries.append(ActivityEntry(
            id=h.id,
            user_id=student_id,
            user_name=name,
            activity_type="homework_submission",
            title=f"Homework submitted",
            score=float(h.score) if h.score is not None else None,
            max_score=float(h.max_possible_score) if h.max_possible_score is not None else None,
            percentage=h.percentage,
            timestamp=_iso(h.submission_date),
            role="student",
        ))

    # StudentResult (exam results)
    sr_rows = (
        db.query(StudentResult, Exam.name)
        .join(Exam, StudentResult.exam_id == Exam.id)
        .filter(StudentResult.student_id == student_id)
        .all()
    )
    for sr, exam_name in sr_rows:
        entries.append(ActivityEntry(
            id=sr.id,
            user_id=student_id,
            user_name=name,
            activity_type="exam_result",
            title=f"Exam: {exam_name or 'Unknown'}",
            score=sr.total_marks_obtained,
            max_score=sr.total_max_marks,
            percentage=sr.overall_percentage,
            timestamp="",
            role="student",
        ))

    entries.sort(key=lambda e: e.timestamp, reverse=True)
    return entries


def get_teacher_activity_entries(teacher_id: int, db: Session, days: int = 30) -> list[ActivityEntry]:
    """Get all activity entries for a single teacher within the last N days."""
    since = datetime.now(timezone.utc) - timedelta(days=days)
    entries: list[ActivityEntry] = []

    teacher = db.query(Student).filter(Student.id == teacher_id).first()
    name = teacher.fullname or "" if teacher else ""

    # Exams created
    exams = (
        db.query(Exam)
        .filter(Exam.teacher_id == teacher_id, Exam.created_at >= since)
        .order_by(Exam.created_at.desc())
        .all()
    )
    for e in exams:
        entries.append(ActivityEntry(
            id=e.id,
            user_id=teacher_id,
            user_name=name,
            activity_type="exam_created",
            title=f"Exam: {e.name or 'Untitled'} ({e.exam_type or 'other'})",
            score=e.average_score,
            max_score=None,
            timestamp=_iso(e.created_at),
            role="teacher",
        ))

    # Homework assigned
    homeworks = (
        db.query(Homework)
        .filter(Homework.teacher_id == teacher_id, Homework.date_assigned >= since)
        .order_by(Homework.date_assigned.desc())
        .all()
    )
    for h in homeworks:
        entries.append(ActivityEntry(
            id=h.id,
            user_id=teacher_id,
            user_name=name,
            activity_type="homework_assigned",
            title=f"Homework: {h.title or 'Untitled'}",
            timestamp=_iso(h.date_assigned),
            role="teacher",
        ))

    # Classwork submissions (teacher evaluated classwork)
    classworks = (
        db.query(ClassworkSubmission)
        .filter(ClassworkSubmission.teacher_name_id == teacher_id, ClassworkSubmission.submission_date >= since)
        .order_by(ClassworkSubmission.submission_date.desc())
        .all()
    )
    for c in classworks:
        entries.append(ActivityEntry(
            id=c.id,
            user_id=teacher_id,
            user_name=name,
            activity_type="classwork",
            title=f"Classwork: {c.assignment_type or 'General'} ({c.class_code or '?'})",
            percentage=c.class_average_percentage,
            timestamp=_iso(c.submission_date),
            role="teacher",
        ))

    entries.sort(key=lambda e: e.timestamp, reverse=True)
    return entries


def get_daily_activity_for_school(school_id: int, db: Session, days: int = 14) -> ActivityOverview:
    """Build a daily activity breakdown for a school over the last N days."""
    since = datetime.now(timezone.utc) - timedelta(days=days)

    # Get all student IDs and teacher IDs in the school
    student_ids = [
        r[0] for r in db.query(Student.id)
        .filter(Student.school_id == school_id, Student.is_student == True)
        .all()
    ]
    teacher_ids = [
        r[0] for r in db.query(Student.id)
        .filter(Student.school_id == school_id, Student.is_teacher == True)
        .all()
    ]

    daily: dict[str, list[ActivityEntry]] = defaultdict(list)

    total_ga = 0
    total_hw = 0
    total_exams = 0
    total_cw = 0

    # Student: GapAnalysis by day
    if student_ids:
        ga_rows = (
            db.query(GapAnalysis, Student.fullname)
            .join(Student, GapAnalysis.student_id == Student.id)
            .filter(GapAnalysis.student_id.in_(student_ids), GapAnalysis.date >= since)
            .order_by(GapAnalysis.date.desc())
            .all()
        )
        for g, fname in ga_rows:
            day_key = g.date.strftime("%Y-%m-%d") if g.date else "unknown"
            daily[day_key].append(ActivityEntry(
                id=g.id,
                user_id=g.student_id,
                user_name=fname or "",
                activity_type="gap_analysis",
                title=f"{g.subject or 'Unknown'} - Ch {g.chapter_number or '?'}",
                subject=g.subject,
                score=g.student_score,
                max_score=g.max_marks,
                percentage=g.percentage,
                timestamp=_iso(g.date),
                role="student",
            ))
            total_ga += 1

        # HomeworkSubmission
        hw_rows = (
            db.query(HomeworkSubmission, Student.fullname)
            .join(Student, HomeworkSubmission.student_name_id == Student.id)
            .filter(HomeworkSubmission.student_name_id.in_(student_ids), HomeworkSubmission.submission_date >= since)
            .order_by(HomeworkSubmission.submission_date.desc())
            .all()
        )
        for h, fname in hw_rows:
            day_key = h.submission_date.strftime("%Y-%m-%d") if h.submission_date else "unknown"
            daily[day_key].append(ActivityEntry(
                id=h.id,
                user_id=h.student_name_id,
                user_name=fname or "",
                activity_type="homework_submission",
                title="Homework submitted",
                score=float(h.score) if h.score is not None else None,
                max_score=float(h.max_possible_score) if h.max_possible_score is not None else None,
                percentage=h.percentage,
                timestamp=_iso(h.submission_date),
                role="student",
            ))
            total_hw += 1

    # Teacher: Exams created
    if teacher_ids:
        exams = (
            db.query(Exam, Student.fullname)
            .join(Student, Exam.teacher_id == Student.id)
            .filter(Exam.teacher_id.in_(teacher_ids), Exam.created_at >= since)
            .order_by(Exam.created_at.desc())
            .all()
        )
        for e, fname in exams:
            day_key = e.created_at.strftime("%Y-%m-%d") if e.created_at else "unknown"
            daily[day_key].append(ActivityEntry(
                id=e.id,
                user_id=e.teacher_id,
                user_name=fname or "",
                activity_type="exam_created",
                title=f"Exam: {e.name or 'Untitled'} ({e.exam_type or 'other'})",
                score=e.average_score,
                timestamp=_iso(e.created_at),
                role="teacher",
            ))
            total_exams += 1

        # Homework assigned
        homeworks = (
            db.query(Homework, Student.fullname)
            .join(Student, Homework.teacher_id == Student.id)
            .filter(Homework.teacher_id.in_(teacher_ids), Homework.date_assigned >= since)
            .order_by(Homework.date_assigned.desc())
            .all()
        )
        for h, fname in homeworks:
            day_key = h.date_assigned.strftime("%Y-%m-%d") if h.date_assigned else "unknown"
            daily[day_key].append(ActivityEntry(
                id=h.id,
                user_id=h.teacher_id,
                user_name=fname or "",
                activity_type="homework_assigned",
                title=f"Homework: {h.title or 'Untitled'}",
                timestamp=_iso(h.date_assigned),
                role="teacher",
            ))
            total_exams += 1  # count as teacher activity

        # Classwork
        classworks = (
            db.query(ClassworkSubmission, Student.fullname)
            .join(Student, ClassworkSubmission.teacher_name_id == Student.id)
            .filter(ClassworkSubmission.teacher_name_id.in_(teacher_ids), ClassworkSubmission.submission_date >= since)
            .order_by(ClassworkSubmission.submission_date.desc())
            .all()
        )
        for c, fname in classworks:
            day_key = c.submission_date.strftime("%Y-%m-%d") if c.submission_date else "unknown"
            daily[day_key].append(ActivityEntry(
                id=c.id,
                user_id=c.teacher_name_id,
                user_name=fname or "",
                activity_type="classwork",
                title=f"Classwork: {c.assignment_type or 'General'} ({c.class_code or '?'})",
                percentage=c.class_average_percentage,
                timestamp=_iso(c.submission_date),
                role="teacher",
            ))
            total_cw += 1

    # Build daily summaries sorted by date desc
    daily_breakdown = []
    for day_key in sorted(daily.keys(), reverse=True):
        entries = daily[day_key]
        student_count = sum(1 for e in entries if e.role == "student")
        teacher_count = sum(1 for e in entries if e.role == "teacher")
        daily_breakdown.append(DailyActivitySummary(
            date=day_key,
            total_submissions=len(entries),
            student_submissions=student_count,
            teacher_activities=teacher_count,
            entries=entries,
        ))

    return ActivityOverview(
        total_student_submissions=total_ga + total_hw,
        total_teacher_activities=total_exams + total_cw,
        total_gap_analysis=total_ga,
        total_homework_submissions=total_hw,
        total_exams_created=total_exams,
        total_classwork=total_cw,
        daily_breakdown=daily_breakdown,
    )
