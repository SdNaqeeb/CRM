"""
WhatsApp messaging service via Interakt API.

Configure in .env:
  INTERAKT_API_KEY – your Interakt API key (Basic auth)

Uses the 'send_inactive_message' approved template (no variables).
"""

import os
import json
import logging
import requests

logger = logging.getLogger(__name__)

INTERAKT_API_KEY = os.getenv("INTERAKT_API_KEY", "")

INTERAKT_URL = "https://api.interakt.ai/v1/public/message/"


def _extract_10_digit(phone: str | None) -> str | None:
    """Extract a 10-digit Indian mobile number (no country code, no leading zero)."""
    if not phone:
        return None
    digits = "".join(c for c in phone if c.isdigit())
    if not digits:
        return None
    # Strip country code if present (91XXXXXXXXXX)
    if len(digits) == 12 and digits.startswith("91"):
        digits = digits[2:]
    # Strip leading zero
    if len(digits) == 11 and digits.startswith("0"):
        digits = digits[1:]
    if len(digits) != 10:
        return None
    return digits


def send_inactive_message(mobile_number: str) -> dict:
    """
    Send a WhatsApp template message to the given mobile number via Interakt.
    The template has no variables (body/header/button values are empty).
    Args:
        mobile_number: 10-digit phone number WITHOUT country code or leading zero.
    Returns:
        A dict with 'success' (bool), 'status_code' (int), and 'response' (dict/str).
    """
    headers = {
        "Authorization": f"Basic {INTERAKT_API_KEY}",
        "Content-Type": "application/json",
    }

    payload = {
        "countryCode": "+91",
        "phoneNumber": mobile_number.strip(),
        "callbackData": "inactive_user_message",
        "type": "Template",
        "template": {
            "name": "smartlearners_inactive_2",
            "languageCode": "en",
        },
    }

    try:
        response = requests.post(
            INTERAKT_URL, headers=headers, data=json.dumps(payload), timeout=15
        )
        return {
            "success": response.status_code in (200, 201),
            "status_code": response.status_code,
            "response": response.json() if response.content else {},
        }
    except requests.exceptions.Timeout:
        return {"success": False, "status_code": None, "response": "Request timed out."}
    except requests.exceptions.RequestException as e:
        return {"success": False, "status_code": None, "response": str(e)}


def send_challenge_notification(phone: str | None, student_name: str = "") -> dict:
    """
    Send a 'You have a new challenge' WhatsApp message to inactive student.
    Uses the same Interakt template for now.
    """
    mobile = _extract_10_digit(phone)
    if not mobile:
        logger.warning("No valid 10-digit phone for student %s (raw: %s)", student_name, phone)
        return {"success": False, "error": "No valid phone number", "phone": phone}

    if not INTERAKT_API_KEY:
        logger.info("[DRY-RUN] Challenge notification to %s (%s)", mobile, student_name)
        return {"success": True, "dry_run": True, "phone": mobile}

    headers = {
        "Authorization": f"Basic {INTERAKT_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {
        "countryCode": "+91",
        "phoneNumber": mobile.strip(),
        "callbackData": "challenge_notification",
        "type": "Template",
        "template": {
            "name": "smartlearners_inactive_2",
            "languageCode": "en",
        },
    }

    try:
        response = requests.post(INTERAKT_URL, headers=headers, data=json.dumps(payload), timeout=15)
        success = response.status_code in (200, 201)
        logger.info("Challenge notification %s for %s (%s): status=%s",
                     "OK" if success else "FAIL", mobile, student_name, response.status_code)
        if success:
            return {"success": True, "phone": mobile}
        error_msg = response.json() if response.content else "Unknown error"
        if isinstance(error_msg, dict):
            error_msg = json.dumps(error_msg)
        return {"success": False, "phone": mobile, "error": str(error_msg)}
    except requests.exceptions.RequestException as e:
        return {"success": False, "phone": mobile, "error": str(e)}


def send_whatsapp_message(phone: str | None, message: str = "", student_name: str = "") -> dict:
    """
    Send WhatsApp alert to a student's phone number.
    Uses the Interakt 'send_inactive_message' template.
    Returns a dict with 'success', 'phone', 'error' keys.
    """
    mobile = _extract_10_digit(phone)
    print(f"Extracted mobile: {mobile} from raw phone: {phone}")
    if not mobile:
        logger.warning("No valid 10-digit phone for student %s (raw: %s)", student_name, phone)
        return {"success": False, "error": "No valid phone number", "phone": phone}

    if not INTERAKT_API_KEY:
        # Dry-run mode — log and return success
        logger.info("[DRY-RUN] WhatsApp to %s (%s)", mobile, student_name)
        return {"success": True, "dry_run": True, "phone": mobile}
    print(f"Sending WhatsApp message to {mobile} for student {student_name}")
    result = send_inactive_message(mobile)
    print(f"Interakt response for {mobile}: {result}")
    logger.info(
        "Interakt %s for %s (%s): status=%s",
        "OK" if result["success"] else "FAIL",
        mobile,
        student_name,
        result.get("status_code"),
    )

    if result["success"]:
        return {"success": True, "phone": mobile}
    else:
        error_msg = result.get("response", "Unknown error")
        if isinstance(error_msg, dict):
            error_msg = json.dumps(error_msg)
        return {"success": False, "phone": mobile, "error": str(error_msg)}
