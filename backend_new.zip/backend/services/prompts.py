"""Centralized prompt templates for AI-powered features."""


MCQ_SYSTEM_ROLE = (
    "You are an expert educational content creator for Indian school students. "
    "You generate rigorous, grade-appropriate Higher-Order Thinking (HOT) "
    "multiple-choice questions aligned to CBSE/ICSE curriculum standards."
)

MCQ_JSON_SCHEMA = """\
[
  {
    "question": "The question text here",
    "options": [
      {"label": "A", "text": "Option A text"},
      {"label": "B", "text": "Option B text"},
      {"label": "C", "text": "Option C text"},
      {"label": "D", "text": "Option D text"}
    ],
    "correct_answer": "A",
    "explanation": "Brief explanation of why this is correct"
  }
]"""

MCQ_REQUIREMENTS = """\
- Questions must test application, analysis, and evaluation skills (Bloom's taxonomy levels 3-6)
- Each question must have exactly 4 options labeled A, B, C, D
- Exactly one correct answer per question
- Provide a brief explanation for the correct answer
- Questions should be grade-appropriate and follow CBSE/ICSE curriculum standards

CRITICAL JSON + MATH RULES:
- For math expressions, use LaTeX wrapped in dollar signs: $x^2 + 3$ for inline math
- Since this is a JSON response, you MUST double-escape all LaTeX backslashes
- Write \\\\frac{{a}}{{b}} NOT \\frac{a}{b} in the JSON string values
- Write \\\\sqrt{{x}} NOT \\sqrt{x} in the JSON string values
- Write \\\\times NOT \\times, \\\\pi NOT \\pi, \\\\theta NOT \\theta
- Example correct JSON value: "$\\\\frac{{1}}{{2}} + \\\\sqrt{{3}}$"
- This is because JSON requires backslashes to be escaped as \\\\
- Do NOT use trailing commas in JSON arrays or objects"""


def build_mcq_prompt(subject: str, grade: str, num_questions: int, concept: str | None = None) -> str:
    """Build the full prompt for MCQ generation."""
    if concept:
        concept_line = f'\nFocus specifically on the concept: "{concept}".'
    else:
        concept_line = (
            f"\nNo specific concept was provided. Cover the most important and frequently examined "
            f"topics from the Grade {grade} {subject} syllabus (CBSE/ICSE). "
            f"Spread the questions across different key chapters and concepts so the student "
            f"gets a well-rounded challenge on the most critical areas of the curriculum."
        )

    return f"""{MCQ_SYSTEM_ROLE}

Generate {num_questions} Higher-Order Thinking (HOT) multiple-choice questions for a Grade {grade} student studying {subject}.
{concept_line}

Requirements:
{MCQ_REQUIREMENTS}

Return ONLY a valid JSON array with this exact structure:
{MCQ_JSON_SCHEMA}"""
