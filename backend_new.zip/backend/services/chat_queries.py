"""
Advanced chat query functions for subject-wise, grade-wise,
student deep-dive, homework, exam, and bottom performer analysis.
"""
from datetime import datetime, timedelta, timezone
from sqlalchemy.orm import Session
from sqlalchemy import func

from models.django_tables import (
    Student, GapAnalysis, HomeworkSubmission, ClassworkSubmission,
    Exam, StudentResult, Classes, Section, OutstandingToken,
)


def _safe_round(val):
    return round(val, 1) if val is not None else None


# ── High Value: Subject-wise breakdown ──

def get_subject_performance(school_id: int, db: Session,
                            subject: str | None = None, days: int = 30) -> dict:
    """Get performance breakdown by subject for a school."""
    since = datetime.now(timezone.utc) - timedelta(days=days)

    student_ids = [
        r[0] for r in db.query(Student.id)
        .filter(Student.school_id == school_id, Student.is_student == True)
        .all()
    ]
    if not student_ids:
        return {"error": "No students found for this school."}

    # Base query for gap analysis grouped by subject
    q = (
        db.query(
            GapAnalysis.subject,
            func.count(GapAnalysis.id),
            func.avg(GapAnalysis.percentage),
            func.count(func.distinct(GapAnalysis.student_id)),
        )
        .filter(
            GapAnalysis.student_id.in_(student_ids),
            GapAnalysis.date >= since,
        )
    )
    if subject:
        q = q.filter(func.lower(GapAnalysis.subject).contains(subject.lower()))
    q = q.group_by(GapAnalysis.subject)
    ga_rows = q.all()

    # Homework by subject is not directly available (no subject column),
    # so we use gap analysis as the primary source

    subjects = []
    for subj_name, count, avg_pct, unique_students in ga_rows:
        subjects.append({
            "subject": subj_name or "Unknown",
            "submissions": count or 0,
            "avg_percentage": _safe_round(avg_pct) or 0,
            "unique_students": unique_students or 0,
        })

    subjects.sort(key=lambda x: x["submissions"], reverse=True)

    return {
        "period_days": days,
        "total_students": len(student_ids),
        "subjects": subjects,
    }


# ── High Value: Student deep dive ──

def get_student_deep_dive(student_id: int, db: Session) -> dict:
    """Get comprehensive report for a single student."""
    student = db.query(Student).filter(Student.id == student_id).first()
    if not student:
        return {"error": "Student not found."}

    now = datetime.now(timezone.utc)

    # Basic info
    grade = None
    if student.class_name_id:
        cls = db.query(Classes.class_name).filter(Classes.id == student.class_name_id).first()
        if cls:
            grade = cls[0]

    section_name = student.section
    if not section_name and student.section_ref_id:
        sec = db.query(Section.name).filter(Section.id == student.section_ref_id).first()
        if sec:
            section_name = sec[0]

    days_since_login = None
    if student.last_login:
        days_since_login = (now - student.last_login).days

    # Recent gap analysis (last 30 days)
    since_30 = now - timedelta(days=30)
    ga_rows = (
        db.query(GapAnalysis)
        .filter(GapAnalysis.student_id == student_id, GapAnalysis.date >= since_30)
        .order_by(GapAnalysis.date.desc())
        .limit(15)
        .all()
    )
    ga_avg = (
        db.query(func.avg(GapAnalysis.percentage))
        .filter(GapAnalysis.student_id == student_id, GapAnalysis.date >= since_30)
        .scalar()
    )

    # Subject-wise averages
    subject_avgs = (
        db.query(
            GapAnalysis.subject,
            func.avg(GapAnalysis.percentage),
            func.count(GapAnalysis.id),
        )
        .filter(GapAnalysis.student_id == student_id, GapAnalysis.date >= since_30)
        .group_by(GapAnalysis.subject)
        .all()
    )

    # Homework submissions
    hw_rows = (
        db.query(HomeworkSubmission)
        .filter(HomeworkSubmission.student_name_id == student_id, HomeworkSubmission.submission_date >= since_30)
        .order_by(HomeworkSubmission.submission_date.desc())
        .limit(10)
        .all()
    )
    hw_avg = (
        db.query(func.avg(HomeworkSubmission.percentage))
        .filter(HomeworkSubmission.student_name_id == student_id, HomeworkSubmission.submission_date >= since_30)
        .scalar()
    )

    # Exam results
    exam_results = (
        db.query(StudentResult, Exam.name, Exam.created_at)
        .join(Exam, StudentResult.exam_id == Exam.id)
        .filter(StudentResult.student_id == student_id)
        .order_by(Exam.created_at.desc())
        .limit(10)
        .all()
    )

    # Login sessions this week
    week_start = (now - timedelta(days=now.weekday())).replace(hour=0, minute=0, second=0, microsecond=0)
    sessions_this_week = (
        db.query(func.count(OutstandingToken.id))
        .filter(OutstandingToken.user_id == student_id, OutstandingToken.created_at >= week_start)
        .scalar()
    ) or 0

    total_sessions = (
        db.query(func.count(OutstandingToken.id))
        .filter(OutstandingToken.user_id == student_id)
        .scalar()
    ) or 0

    return {
        "name": student.fullname or student.username or "Unknown",
        "grade": grade,
        "section": section_name,
        "last_login": student.last_login.isoformat() if student.last_login else "Never",
        "days_since_login": days_since_login,
        "sessions_this_week": sessions_this_week,
        "total_sessions": total_sessions,
        "practice_avg_30d": _safe_round(ga_avg) or 0,
        "practice_count_30d": len(ga_rows),
        "homework_avg_30d": _safe_round(hw_avg) or 0,
        "homework_count_30d": len(hw_rows),
        "subject_breakdown": [
            {"subject": s or "Unknown", "avg_pct": _safe_round(a) or 0, "count": c}
            for s, a, c in subject_avgs
        ],
        "recent_practices": [
            {
                "subject": g.subject,
                "chapter": g.chapter_number,
                "percentage": g.percentage,
                "date": g.date.isoformat() if g.date else None,
            }
            for g in ga_rows[:5]
        ],
        "recent_homework": [
            {
                "percentage": h.percentage,
                "score": f"{h.score}/{h.max_possible_score}" if h.score is not None else None,
                "date": h.submission_date.isoformat() if h.submission_date else None,
            }
            for h in hw_rows[:5]
        ],
        "exam_results": [
            {
                "exam": name,
                "percentage": sr.overall_percentage,
                "grade": sr.grade,
                "date": dt.isoformat() if dt else None,
            }
            for sr, name, dt in exam_results[:5]
        ],
    }


# ── High Value: Grade/section filtering ──

def get_grade_performance(school_id: int, db: Session,
                          grade: str | None = None, section: str | None = None,
                          days: int = 30) -> dict:
    """Get performance for a specific grade/section in a school."""
    since = datetime.now(timezone.utc) - timedelta(days=days)

    # Find students matching grade/section
    q = db.query(Student).filter(
        Student.school_id == school_id,
        Student.is_student == True,
    )

    # Match grade via class_name
    class_ids = None
    if grade:
        class_ids = [
            r[0] for r in db.query(Classes.id)
            .filter(func.lower(Classes.class_name).contains(grade.lower()))
            .all()
        ]
        if class_ids:
            q = q.filter(Student.class_name_id.in_(class_ids))
        else:
            return {"error": f"No class matching '{grade}' found."}

    if section:
        q = q.filter(func.lower(Student.section).contains(section.lower()))

    students = q.all()
    if not students:
        return {"error": f"No students found for grade={grade}, section={section}."}

    student_ids = [s.id for s in students]

    # Gap analysis stats
    ga_avg = (
        db.query(func.avg(GapAnalysis.percentage))
        .filter(GapAnalysis.student_id.in_(student_ids), GapAnalysis.date >= since)
        .scalar()
    )
    ga_count = (
        db.query(func.count(GapAnalysis.id))
        .filter(GapAnalysis.student_id.in_(student_ids), GapAnalysis.date >= since)
        .scalar()
    ) or 0

    # Homework stats
    hw_avg = (
        db.query(func.avg(HomeworkSubmission.percentage))
        .filter(HomeworkSubmission.student_name_id.in_(student_ids), HomeworkSubmission.submission_date >= since)
        .scalar()
    )
    hw_count = (
        db.query(func.count(HomeworkSubmission.id))
        .filter(HomeworkSubmission.student_name_id.in_(student_ids), HomeworkSubmission.submission_date >= since)
        .scalar()
    ) or 0

    # Active students
    week_start = (datetime.now(timezone.utc) - timedelta(days=datetime.now(timezone.utc).weekday())).replace(
        hour=0, minute=0, second=0, microsecond=0
    )
    active_count = (
        db.query(func.count(Student.id))
        .filter(Student.id.in_(student_ids), Student.last_login >= week_start)
        .scalar()
    ) or 0

    inactive_count = (
        db.query(func.count(Student.id))
        .filter(
            Student.id.in_(student_ids),
            (Student.last_login < week_start) | (Student.last_login.is_(None)),
        )
        .scalar()
    ) or 0

    return {
        "grade": grade,
        "section": section,
        "total_students": len(students),
        "active_this_week": active_count,
        "inactive": inactive_count,
        "practice_avg_pct": _safe_round(ga_avg) or 0,
        "practice_submissions": ga_count,
        "homework_avg_pct": _safe_round(hw_avg) or 0,
        "homework_submissions": hw_count,
        "period_days": days,
    }


# ── High Value: Why is a student inactive? ──

def get_student_inactivity_reason(student_id: int, db: Session) -> dict:
    """Analyze why a student is inactive — last activity, scores before going inactive."""
    student = db.query(Student).filter(Student.id == student_id).first()
    if not student:
        return {"error": "Student not found."}

    name = student.fullname or student.username or "Unknown"
    now = datetime.now(timezone.utc)

    days_since_login = None
    if student.last_login:
        days_since_login = (now - student.last_login).days

    # Last gap analysis
    last_ga = (
        db.query(GapAnalysis)
        .filter(GapAnalysis.student_id == student_id)
        .order_by(GapAnalysis.date.desc())
        .first()
    )

    # Last homework
    last_hw = (
        db.query(HomeworkSubmission)
        .filter(HomeworkSubmission.student_name_id == student_id)
        .order_by(HomeworkSubmission.submission_date.desc())
        .first()
    )

    # Score trend before going inactive (last 5 gap analyses)
    recent_scores = (
        db.query(GapAnalysis.percentage, GapAnalysis.date, GapAnalysis.subject)
        .filter(GapAnalysis.student_id == student_id)
        .order_by(GapAnalysis.date.desc())
        .limit(5)
        .all()
    )

    # Total activity count
    total_ga = db.query(func.count(GapAnalysis.id)).filter(GapAnalysis.student_id == student_id).scalar() or 0
    total_hw = db.query(func.count(HomeworkSubmission.id)).filter(HomeworkSubmission.student_name_id == student_id).scalar() or 0

    return {
        "name": name,
        "days_since_login": days_since_login,
        "last_login": student.last_login.isoformat() if student.last_login else "Never logged in",
        "last_practice": {
            "subject": last_ga.subject if last_ga else None,
            "percentage": last_ga.percentage if last_ga else None,
            "date": last_ga.date.isoformat() if last_ga and last_ga.date else None,
        } if last_ga else "No practice activity ever",
        "last_homework": {
            "percentage": last_hw.percentage if last_hw else None,
            "date": last_hw.submission_date.isoformat() if last_hw and last_hw.submission_date else None,
        } if last_hw else "No homework submitted ever",
        "total_practices": total_ga,
        "total_homework": total_hw,
        "recent_scores_before_inactive": [
            {"subject": s, "percentage": p, "date": d.isoformat() if d else None}
            for p, d, s in recent_scores
        ],
    }


# ── Medium Value: Homework completion rates ──

def get_homework_stats(school_id: int, db: Session, days: int = 7) -> dict:
    """Get homework submission stats for a school."""
    since = datetime.now(timezone.utc) - timedelta(days=days)

    student_ids = [
        r[0] for r in db.query(Student.id)
        .filter(Student.school_id == school_id, Student.is_student == True)
        .all()
    ]
    if not student_ids:
        return {"error": "No students found."}

    # Total submissions in period
    submissions = (
        db.query(
            func.count(HomeworkSubmission.id),
            func.avg(HomeworkSubmission.percentage),
            func.count(func.distinct(HomeworkSubmission.student_name_id)),
        )
        .filter(
            HomeworkSubmission.student_name_id.in_(student_ids),
            HomeworkSubmission.submission_date >= since,
        )
        .one()
    )
    count, avg_pct, unique_students = submissions

    return {
        "period_days": days,
        "total_students": len(student_ids),
        "students_who_submitted": unique_students or 0,
        "students_not_submitted": len(student_ids) - (unique_students or 0),
        "total_submissions": count or 0,
        "avg_percentage": _safe_round(avg_pct) or 0,
    }


# ── Medium Value: Exam analysis ──

def get_exam_analysis(school_id: int, db: Session, days: int = 30) -> dict:
    """Get recent exam performance for a school."""
    since = datetime.now(timezone.utc) - timedelta(days=days)

    teacher_ids = [
        r[0] for r in db.query(Student.id)
        .filter(Student.school_id == school_id, Student.is_teacher == True)
        .all()
    ]
    student_ids = [
        r[0] for r in db.query(Student.id)
        .filter(Student.school_id == school_id, Student.is_student == True)
        .all()
    ]

    # Recent exams
    exams = (
        db.query(Exam)
        .filter(Exam.teacher_id.in_(teacher_ids) if teacher_ids else True, Exam.created_at >= since)
        .order_by(Exam.created_at.desc())
        .limit(10)
        .all()
    )

    exam_details = []
    for exam in exams:
        results = (
            db.query(
                func.count(StudentResult.id),
                func.avg(StudentResult.overall_percentage),
                func.min(StudentResult.overall_percentage),
                func.max(StudentResult.overall_percentage),
            )
            .filter(StudentResult.exam_id == exam.id)
            .one()
        )
        r_count, r_avg, r_min, r_max = results
        exam_details.append({
            "name": exam.name or "Untitled",
            "type": exam.exam_type or "other",
            "date": exam.created_at.isoformat() if exam.created_at else None,
            "students_appeared": r_count or 0,
            "avg_percentage": _safe_round(r_avg) or 0,
            "min_percentage": _safe_round(r_min) or 0,
            "max_percentage": _safe_round(r_max) or 0,
        })

    return {
        "period_days": days,
        "total_exams": len(exams),
        "exams": exam_details,
    }


# ── Medium Value: Bottom performers ──

def get_bottom_performers(school_id: int, db: Session, days: int = 30, limit: int = 10) -> dict:
    """Get students with lowest average scores."""
    since = datetime.now(timezone.utc) - timedelta(days=days)

    student_ids = [
        r[0] for r in db.query(Student.id)
        .filter(Student.school_id == school_id, Student.is_student == True)
        .all()
    ]
    if not student_ids:
        return {"error": "No students found."}

    # Students with lowest avg gap analysis scores
    rows = (
        db.query(
            GapAnalysis.student_id,
            func.avg(GapAnalysis.percentage).label("avg_pct"),
            func.count(GapAnalysis.id).label("count"),
        )
        .filter(GapAnalysis.student_id.in_(student_ids), GapAnalysis.date >= since)
        .group_by(GapAnalysis.student_id)
        .having(func.count(GapAnalysis.id) >= 2)  # At least 2 submissions
        .order_by(func.avg(GapAnalysis.percentage).asc())
        .limit(limit)
        .all()
    )

    results = []
    for sid, avg_pct, count in rows:
        student = db.query(Student).filter(Student.id == sid).first()
        grade = None
        if student and student.class_name_id:
            cls = db.query(Classes.class_name).filter(Classes.id == student.class_name_id).first()
            if cls:
                grade = cls[0]

        results.append({
            "name": student.fullname or student.username or "Unknown" if student else "Unknown",
            "grade": grade,
            "avg_percentage": _safe_round(avg_pct) or 0,
            "submissions": count or 0,
        })

    return {
        "period_days": days,
        "students": results,
        "count": len(results),
    }


# ── Medium Value: Flexible time comparison ──

def get_period_improvement(school_id: int, db: Session, days: int = 30) -> dict:
    """Compare current period vs previous period (flexible: 7, 30, 90 days)."""
    now = datetime.now(timezone.utc)
    current_start = now - timedelta(days=days)
    previous_start = current_start - timedelta(days=days)

    student_ids = [
        r[0] for r in db.query(Student.id)
        .filter(Student.school_id == school_id, Student.is_student == True)
        .all()
    ]
    if not student_ids:
        return {"error": "No students found."}

    def _period_stats(since, until):
        ga = db.query(
            func.count(GapAnalysis.id), func.avg(GapAnalysis.percentage)
        ).filter(
            GapAnalysis.student_id.in_(student_ids),
            GapAnalysis.date >= since, GapAnalysis.date < until,
        ).one()

        hw = db.query(
            func.count(HomeworkSubmission.id), func.avg(HomeworkSubmission.percentage)
        ).filter(
            HomeworkSubmission.student_name_id.in_(student_ids),
            HomeworkSubmission.submission_date >= since, HomeworkSubmission.submission_date < until,
        ).one()

        active = db.query(func.count(Student.id)).filter(
            Student.id.in_(student_ids), Student.last_login >= since, Student.last_login < until,
        ).scalar() or 0

        return {
            "practice_count": ga[0] or 0,
            "practice_avg": _safe_round(ga[1]) or 0,
            "homework_count": hw[0] or 0,
            "homework_avg": _safe_round(hw[1]) or 0,
            "active_students": active,
        }

    current = _period_stats(current_start, now)
    previous = _period_stats(previous_start, current_start)

    def _pct(cur, prev):
        if prev == 0:
            return None
        return round(((cur - prev) / prev) * 100, 1)

    return {
        "period_days": days,
        "current_period": f"{current_start.strftime('%Y-%m-%d')} to now",
        "previous_period": f"{previous_start.strftime('%Y-%m-%d')} to {current_start.strftime('%Y-%m-%d')}",
        "current": current,
        "previous": previous,
        "changes": {
            "practice_count": _pct(current["practice_count"], previous["practice_count"]),
            "practice_avg": _pct(current["practice_avg"], previous["practice_avg"]),
            "homework_count": _pct(current["homework_count"], previous["homework_count"]),
            "homework_avg": _pct(current["homework_avg"], previous["homework_avg"]),
            "active_students": _pct(current["active_students"], previous["active_students"]),
        },
        "total_students": len(student_ids),
    }


# ── Improvement Plan: Class + Exam type specific ──

def get_class_exam_improvement(
    school_id: int, db: Session,
    grade: str, exam_type: str | None = None, days: int = 14,
) -> dict:
    """Get improvement data for a specific class filtered by exam type,
    comparing current period vs previous period."""
    now = datetime.now(timezone.utc)
    current_start = now - timedelta(days=days)
    previous_start = current_start - timedelta(days=days)

    # Find class IDs matching the grade
    class_ids = [
        r[0] for r in db.query(Classes.id)
        .filter(func.lower(Classes.class_name).contains(grade.lower()))
        .all()
    ]
    if not class_ids:
        return {"error": f"No class matching '{grade}' found."}

    # Get students in this class for this school
    student_ids = [
        r[0] for r in db.query(Student.id)
        .filter(
            Student.school_id == school_id,
            Student.is_student == True,
            Student.class_name_id.in_(class_ids),
        )
        .all()
    ]
    if not student_ids:
        return {"error": f"No students found for Class {grade}."}

    # Get teacher IDs for this school
    teacher_ids = [
        r[0] for r in db.query(Student.id)
        .filter(Student.school_id == school_id, Student.is_teacher == True)
        .all()
    ]

    # ── Practice (Gap Analysis) stats for current & previous period ──
    def _practice_stats(since, until):
        q = db.query(
            func.count(GapAnalysis.id),
            func.count(func.distinct(GapAnalysis.student_id)),
        ).filter(
            GapAnalysis.student_id.in_(student_ids),
            GapAnalysis.date >= since, GapAnalysis.date < until,
        )
        count, unique = q.one()
        return {
            "count": count or 0,
            "unique_students": unique or 0,
        }

    # ── Subject breakdown for current period ──
    subject_rows = (
        db.query(
            GapAnalysis.subject,
            func.count(GapAnalysis.id),
            func.avg(GapAnalysis.percentage),
        )
        .filter(
            GapAnalysis.student_id.in_(student_ids),
            GapAnalysis.date >= current_start,
        )
        .group_by(GapAnalysis.subject)
        .all()
    )
    subjects = [
        {"subject": s or "Unknown", "submissions": c or 0, "avg_pct": _safe_round(a) or 0}
        for s, c, a in subject_rows
    ]
    subjects.sort(key=lambda x: x["avg_pct"])  # worst first for improvement focus

    # ── Homework stats ──
    def _hw_stats(since, until):
        q = db.query(
            func.count(HomeworkSubmission.id),
            func.count(func.distinct(HomeworkSubmission.student_name_id)),
        ).filter(
            HomeworkSubmission.student_name_id.in_(student_ids),
            HomeworkSubmission.submission_date >= since,
            HomeworkSubmission.submission_date < until,
        )
        count, unique = q.one()
        return {
            "count": count or 0,
            "unique_students": unique or 0,
        }

    # ── Exam stats (filtered by exam_type if provided) ──
    def _exam_stats(since, until):
        eq = db.query(Exam).filter(Exam.created_at >= since, Exam.created_at < until)
        if teacher_ids:
            eq = eq.filter(Exam.teacher_id.in_(teacher_ids))
        if exam_type:
            eq = eq.filter(func.lower(Exam.exam_type) == exam_type.lower())
        # Filter exams by class via section
        section_ids = [
            r[0] for r in db.query(Section.id)
            .filter(Section.school_id == school_id, Section.class_name_id.in_(class_ids))
            .all()
        ]
        if section_ids:
            eq = eq.filter(Exam.class_section_id.in_(section_ids))
        exams = eq.all()
        if not exams:
            return {"exam_count": 0, "avg_percentage": 0, "students_appeared": 0, "exams": []}
        exam_ids = [e.id for e in exams]
        results = (
            db.query(
                func.count(StudentResult.id),
                func.avg(StudentResult.overall_percentage),
            )
            .filter(
                StudentResult.exam_id.in_(exam_ids),
                StudentResult.student_id.in_(student_ids),
            )
            .one()
        )
        r_count, r_avg = results
        exam_details = []
        for exam in exams[:5]:  # top 5 recent
            er = db.query(
                func.avg(StudentResult.overall_percentage),
                func.count(StudentResult.id),
            ).filter(
                StudentResult.exam_id == exam.id,
                StudentResult.student_id.in_(student_ids),
            ).one()
            exam_details.append({
                "name": exam.name or "Untitled",
                "type": exam.exam_type,
                "avg_pct": _safe_round(er[0]) or 0,
                "students": er[1] or 0,
                "date": exam.created_at.isoformat() if exam.created_at else None,
            })
        return {
            "exam_count": len(exams),
            "avg_percentage": _safe_round(r_avg) or 0,
            "students_appeared": r_count or 0,
            "exams": exam_details,
        }

    # ── Bottom performers in this class ──
    bottom_rows = (
        db.query(
            GapAnalysis.student_id,
            func.avg(GapAnalysis.percentage).label("avg_pct"),
        )
        .filter(
            GapAnalysis.student_id.in_(student_ids),
            GapAnalysis.date >= current_start,
        )
        .group_by(GapAnalysis.student_id)
        .having(func.count(GapAnalysis.id) >= 1)
        .order_by(func.avg(GapAnalysis.percentage).asc())
        .limit(5)
        .all()
    )
    struggling_students = []
    for sid, avg_pct in bottom_rows:
        student = db.query(Student).filter(Student.id == sid).first()
        struggling_students.append({
            "name": student.fullname or student.username or "Unknown" if student else "Unknown",
            "avg_pct": _safe_round(avg_pct) or 0,
        })

    # ── Active vs Inactive ──
    active_count = (
        db.query(func.count(Student.id))
        .filter(Student.id.in_(student_ids), Student.last_login >= current_start)
        .scalar()
    ) or 0

    practice_current = _practice_stats(current_start, now)
    practice_previous = _practice_stats(previous_start, current_start)
    hw_current = _hw_stats(current_start, now)
    hw_previous = _hw_stats(previous_start, current_start)
    exam_current = _exam_stats(current_start, now)
    exam_previous = _exam_stats(previous_start, current_start)

    def _pct(cur, prev):
        if prev == 0:
            return None
        return round(((cur - prev) / prev) * 100, 1)

    return {
        "grade": grade,
        "exam_type_filter": exam_type or "all",

        "timeline_days": days,
        "total_students": len(student_ids),
        "active_in_period": active_count,
        "inactive_in_period": len(student_ids) - active_count,
        "practice": {
            "current": practice_current,
            "previous": practice_previous,
            "change_pct": _pct(practice_current["count"], practice_previous["count"]),
        },
        "homework": {
            "current": hw_current,
            "previous": hw_previous,
            "change_pct": _pct(hw_current["count"], hw_previous["count"]),
        },
        "exams": {
            "current": exam_current,
            "previous": exam_previous,
        },
        "weak_subjects": subjects[:5],
        "struggling_students": struggling_students,
        "period": {
            "current": f"{current_start.strftime('%Y-%m-%d')} to now",
            "previous": f"{previous_start.strftime('%Y-%m-%d')} to {current_start.strftime('%Y-%m-%d')}",
        },
    }


# ── Compare Classes Performance ──

def get_compare_classes(school_id: int, db: Session, days: int = 14) -> dict:
    """Compare performance across all classes in a school."""
    since = datetime.now(timezone.utc) - timedelta(days=days)
    week_start = (datetime.now(timezone.utc) - timedelta(
        days=datetime.now(timezone.utc).weekday()
    )).replace(hour=0, minute=0, second=0, microsecond=0)

    # Get all students for this school
    all_students = (
        db.query(Student)
        .filter(Student.school_id == school_id, Student.is_student == True)
        .all()
    )
    if not all_students:
        return {"error": "No students found for this school."}

    # Group students by class
    class_map: dict[int, list[int]] = {}
    for s in all_students:
        if s.class_name_id:
            class_map.setdefault(s.class_name_id, []).append(s.id)

    if not class_map:
        return {"error": "No class data available for students."}

    # Fetch class names
    class_ids = list(class_map.keys())
    class_names = {
        r.id: r.class_name
        for r in db.query(Classes).filter(Classes.id.in_(class_ids)).all()
    }

    classes = []
    for cid, student_ids in class_map.items():
        name = class_names.get(cid, "Unknown")

        # Practice stats
        ga = db.query(
            func.count(GapAnalysis.id),
            func.avg(GapAnalysis.percentage),
        ).filter(
            GapAnalysis.student_id.in_(student_ids),
            GapAnalysis.date >= since,
        ).one()

        # Homework stats
        hw = db.query(
            func.count(HomeworkSubmission.id),
            func.avg(HomeworkSubmission.percentage),
        ).filter(
            HomeworkSubmission.student_name_id.in_(student_ids),
            HomeworkSubmission.submission_date >= since,
        ).one()

        # Active this week
        active = (
            db.query(func.count(Student.id))
            .filter(Student.id.in_(student_ids), Student.last_login >= week_start)
            .scalar()
        ) or 0

        # Inactive
        inactive = len(student_ids) - active

        classes.append({
            "class": name,
            "total_students": len(student_ids),
            "active_this_week": active,
            "inactive": inactive,
            "practice_count": ga[0] or 0,
            "practice_avg_pct": _safe_round(ga[1]) or 0,
            "homework_count": hw[0] or 0,
            "homework_avg_pct": _safe_round(hw[1]) or 0,
        })

    # Sort by practice average descending (best first)
    classes.sort(key=lambda x: x["practice_avg_pct"], reverse=True)

    return {
        "period_days": days,
        "total_classes": len(classes),
        "classes": classes,
    }
