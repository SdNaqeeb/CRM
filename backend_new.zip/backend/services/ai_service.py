"""AI service for generating MCQ questions."""
import json
import logging
import re
from google import genai
from google.genai import types
from config import GEMINI_API_KEY, AI_MODEL
from services.prompts import build_mcq_prompt

logger = logging.getLogger(__name__)

client = genai.Client(api_key=GEMINI_API_KEY)

# Only these 3 JSON escapes are structural (affect JSON parsing).
# All others (\n, \t, \f, \b, \r, \letter) are treated as LaTeX.
_STRUCTURAL_ESCAPES = set('"\\/')
_HEX_CHARS = set('0123456789abcdefABCDEF')

MAX_RETRIES = 3


def _fix_json_backslashes(raw: str) -> str:
    """Escape backslashes inside JSON string values that are LaTeX.

    Walks character by character, tracking JSON string boundaries.
    Inside strings, doubles any backslash that is NOT:
      - \\"  (escaped quote — needed for JSON structure)
      - \\\\ (escaped backslash — already doubled)
      - \\/  (escaped slash)
      - \\uXXXX (Unicode escape with exactly 4 hex digits)

    This means \\n, \\t, \\f, \\b, \\r and all LaTeX commands
    get doubled so json.loads produces literal backslash + letter,
    exactly what KaTeX needs on the frontend.
    """
    result = []
    in_string = False
    i = 0
    n = len(raw)

    while i < n:
        ch = raw[i]

        if not in_string:
            if ch == '"':
                in_string = True
            result.append(ch)
            i += 1
        else:
            if ch == '"':
                in_string = False
                result.append(ch)
                i += 1
            elif ch == '\\':
                if i + 1 < n:
                    next_ch = raw[i + 1]
                    if next_ch in _STRUCTURAL_ESCAPES:
                        result.append(ch)
                        result.append(next_ch)
                        i += 2
                    elif next_ch == 'u' and i + 5 < n and all(c in _HEX_CHARS for c in raw[i + 2:i + 6]):
                        result.append(raw[i:i + 6])
                        i += 6
                    else:
                        result.append('\\\\')
                        i += 1
                else:
                    result.append('\\\\')
                    i += 1
            else:
                result.append(ch)
                i += 1

    return ''.join(result)


def _fix_json_structure(raw: str) -> str:
    """Fix common structural JSON issues from LLM output."""
    raw = re.sub(r',\s*([}\]])', r'\1', raw)
    raw = raw.lstrip('\ufeff\u200b')
    return raw


def _clean_raw(raw: str) -> str:
    """Strip markdown code fences and whitespace."""
    cleaned = raw.strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
    cleaned = re.sub(r"\s*```$", "", cleaned.strip())
    return cleaned


def _try_parse_json(raw: str) -> list[dict]:
    """Parse LLM JSON response with multiple fallback strategies."""
    cleaned = _clean_raw(raw)

    # Strategy 1: Fix backslashes + structure, then parse
    try:
        fixed = _fix_json_backslashes(cleaned)
        fixed = _fix_json_structure(fixed)
        result = json.loads(fixed)
        if isinstance(result, list):
            return result
    except json.JSONDecodeError:
        pass

    # Strategy 2: Extract outermost [...] and try again
    try:
        start = cleaned.index('[')
        depth = 0
        end = start
        for j in range(start, len(cleaned)):
            if cleaned[j] == '[':
                depth += 1
            elif cleaned[j] == ']':
                depth -= 1
                if depth == 0:
                    end = j + 1
                    break
        extracted = cleaned[start:end]
        fixed = _fix_json_backslashes(extracted)
        fixed = _fix_json_structure(fixed)
        result = json.loads(fixed)
        if isinstance(result, list):
            return result
    except (json.JSONDecodeError, ValueError):
        pass

    # Strategy 3: strict=False as last resort
    try:
        fixed = _fix_json_backslashes(cleaned)
        fixed = _fix_json_structure(fixed)
        result = json.loads(fixed, strict=False)
        if isinstance(result, list):
            return result
    except json.JSONDecodeError:
        pass

    raise ValueError("Could not parse AI response as JSON array")


def generate_mcq_questions(subject: str, grade: str, num_questions: int, concept: str | None = None) -> list[dict]:
    """Call AI to generate MCQ questions with retry logic."""
    prompt = build_mcq_prompt(subject, grade, num_questions, concept)
    last_error = None

    for attempt in range(MAX_RETRIES):
        try:
            contents = [
                types.Content(
                    role="user",
                    parts=[types.Part.from_text(text=prompt)],
                ),
            ]

            config = types.GenerateContentConfig(
                thinking_config=types.ThinkingConfig(
                    thinking_level="HIGH",
                ),
                response_mime_type="application/json",
                temperature=0.7 + (attempt * 0.1),
            )

            response = client.models.generate_content(
                model=AI_MODEL,
                contents=contents,
                config=config,
            )

            raw = response.text
            logger.info(f"AI attempt {attempt + 1}, response length={len(raw)}")

            questions = _try_parse_json(raw)

            validated = []
            for q in questions:
                if isinstance(q, dict) and 'question' in q and 'options' in q:
                    validated.append(q)

            if validated:
                return validated

            logger.warning(f"Attempt {attempt + 1}: No valid questions in response")

        except Exception as e:
            last_error = e
            logger.warning(f"Attempt {attempt + 1} failed: {e}")
            continue

    raise ValueError(f"Failed to generate questions after {MAX_RETRIES} attempts: {last_error}")
