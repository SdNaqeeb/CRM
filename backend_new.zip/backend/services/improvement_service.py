"""
Week-over-week improvement comparison service.
Compares this week vs last week across academic performance and engagement.
"""
from datetime import datetime, timedelta, timezone
from sqlalchemy.orm import Session
from sqlalchemy import func

from models.django_tables import (
    Student, GapAnalysis, HomeworkSubmission, ClassworkSubmission,
    Exam, StudentResult, OutstandingToken,
)


def _week_bounds():
    """Return (this_week_start, last_week_start, last_week_end)."""
    now = datetime.now(timezone.utc)
    this_week_start = (now - timedelta(days=now.weekday())).replace(
        hour=0, minute=0, second=0, microsecond=0
    )
    last_week_start = this_week_start - timedelta(weeks=1)
    return this_week_start, last_week_start, this_week_start


def _pct_change(current, previous):
    """Calculate percentage change. Returns None if previous is 0."""
    if previous == 0:
        return None
    return round(((current - previous) / previous) * 100, 1)


def _safe_round(val):
    return round(val, 1) if val is not None else None


def get_school_improvement(school_id: int, db: Session) -> dict:
    """Compare this week vs last week for a school across all academic tables."""
    this_week_start, last_week_start, last_week_end = _week_bounds()

    # Get student and teacher IDs for this school
    student_ids = [
        r[0] for r in db.query(Student.id)
        .filter(Student.school_id == school_id, Student.is_student == True)
        .all()
    ]
    teacher_ids = [
        r[0] for r in db.query(Student.id)
        .filter(Student.school_id == school_id, Student.is_teacher == True)
        .all()
    ]

    result = {
        "school_id": school_id,
        "period": {
            "this_week_start": this_week_start.strftime("%Y-%m-%d"),
            "last_week_start": last_week_start.strftime("%Y-%m-%d"),
        },
    }

    if not student_ids:
        result["error"] = "No students found for this school"
        return result

    # ── 1. Gap Analysis (student practice scores) ──
    ga_this = _gap_analysis_stats(db, student_ids, this_week_start, None)
    ga_last = _gap_analysis_stats(db, student_ids, last_week_start, last_week_end)
    result["gap_analysis"] = {
        "this_week": ga_this,
        "last_week": ga_last,
        "avg_score_change": _pct_change(ga_this["avg_percentage"], ga_last["avg_percentage"]),
        "submission_count_change": _pct_change(ga_this["count"], ga_last["count"]),
    }

    # ── 2. Homework Submissions ──
    hw_this = _homework_stats(db, student_ids, this_week_start, None)
    hw_last = _homework_stats(db, student_ids, last_week_start, last_week_end)
    result["homework"] = {
        "this_week": hw_this,
        "last_week": hw_last,
        "avg_score_change": _pct_change(hw_this["avg_percentage"], hw_last["avg_percentage"]),
        "submission_count_change": _pct_change(hw_this["count"], hw_last["count"]),
    }

    # ── 3. Classwork (teacher-side, class averages) ──
    cw_this = _classwork_stats(db, teacher_ids, this_week_start, None)
    cw_last = _classwork_stats(db, teacher_ids, last_week_start, last_week_end)
    result["classwork"] = {
        "this_week": cw_this,
        "last_week": cw_last,
        "avg_score_change": _pct_change(cw_this["avg_percentage"], cw_last["avg_percentage"]),
        "count_change": _pct_change(cw_this["count"], cw_last["count"]),
    }

    # ── 4. Exams + Results ──
    exam_this = _exam_stats(db, student_ids, teacher_ids, this_week_start, None)
    exam_last = _exam_stats(db, student_ids, teacher_ids, last_week_start, last_week_end)
    result["exams"] = {
        "this_week": exam_this,
        "last_week": exam_last,
        "avg_score_change": _pct_change(exam_this["avg_percentage"], exam_last["avg_percentage"]),
    }

    # ── 5. Login sessions (engagement) ──
    sessions_this = _session_count(db, school_id, this_week_start, None)
    sessions_last = _session_count(db, school_id, last_week_start, last_week_end)
    result["sessions"] = {
        "this_week": sessions_this,
        "last_week": sessions_last,
        "change": _pct_change(sessions_this, sessions_last),
    }

    # ── 6. Active students (logged in within the period) ──
    active_this = _active_student_count(db, student_ids, this_week_start, None)
    active_last = _active_student_count(db, student_ids, last_week_start, last_week_end)
    result["active_students"] = {
        "this_week": active_this,
        "last_week": active_last,
        "total_students": len(student_ids),
        "change": _pct_change(active_this, active_last),
    }

    return result


# ── Helper query functions ──

def _gap_analysis_stats(db: Session, student_ids: list[int],
                        since: datetime, until: datetime | None) -> dict:
    q = db.query(
        func.count(GapAnalysis.id),
        func.avg(GapAnalysis.percentage),
        func.avg(GapAnalysis.student_score),
    ).filter(
        GapAnalysis.student_id.in_(student_ids),
        GapAnalysis.date >= since,
    )
    if until:
        q = q.filter(GapAnalysis.date < until)
    count, avg_pct, avg_score = q.one()
    return {
        "count": count or 0,
        "avg_percentage": _safe_round(avg_pct) or 0,
        "avg_score": _safe_round(avg_score) or 0,
    }


def _homework_stats(db: Session, student_ids: list[int],
                    since: datetime, until: datetime | None) -> dict:
    q = db.query(
        func.count(HomeworkSubmission.id),
        func.avg(HomeworkSubmission.percentage),
    ).filter(
        HomeworkSubmission.student_name_id.in_(student_ids),
        HomeworkSubmission.submission_date >= since,
    )
    if until:
        q = q.filter(HomeworkSubmission.submission_date < until)
    count, avg_pct = q.one()
    return {
        "count": count or 0,
        "avg_percentage": _safe_round(avg_pct) or 0,
    }


def _classwork_stats(db: Session, teacher_ids: list[int],
                     since: datetime, until: datetime | None) -> dict:
    if not teacher_ids:
        return {"count": 0, "avg_percentage": 0}
    q = db.query(
        func.count(ClassworkSubmission.id),
        func.avg(ClassworkSubmission.class_average_percentage),
    ).filter(
        ClassworkSubmission.teacher_name_id.in_(teacher_ids),
        ClassworkSubmission.submission_date >= since,
    )
    if until:
        q = q.filter(ClassworkSubmission.submission_date < until)
    count, avg_pct = q.one()
    return {
        "count": count or 0,
        "avg_percentage": _safe_round(avg_pct) or 0,
    }


def _exam_stats(db: Session, student_ids: list[int], teacher_ids: list[int],
                since: datetime, until: datetime | None) -> dict:
    # Count exams created by teachers in this period
    eq = db.query(func.count(Exam.id)).filter(Exam.created_at >= since)
    if teacher_ids:
        eq = eq.filter(Exam.teacher_id.in_(teacher_ids))
    if until:
        eq = eq.filter(Exam.created_at < until)
    exam_count = eq.scalar() or 0

    # Get exam IDs in this period for result lookup
    eid_q = db.query(Exam.id).filter(Exam.created_at >= since)
    if teacher_ids:
        eid_q = eid_q.filter(Exam.teacher_id.in_(teacher_ids))
    if until:
        eid_q = eid_q.filter(Exam.created_at < until)
    exam_ids = [r[0] for r in eid_q.all()]

    avg_pct = 0
    result_count = 0
    if exam_ids and student_ids:
        rq = db.query(
            func.count(StudentResult.id),
            func.avg(StudentResult.overall_percentage),
        ).filter(
            StudentResult.exam_id.in_(exam_ids),
            StudentResult.student_id.in_(student_ids),
        )
        result_count, avg_pct = rq.one()
        result_count = result_count or 0
        avg_pct = _safe_round(avg_pct) or 0

    return {
        "exams_created": exam_count,
        "results_count": result_count,
        "avg_percentage": avg_pct,
    }


def _session_count(db: Session, school_id: int,
                   since: datetime, until: datetime | None) -> int:
    q = (
        db.query(func.count(OutstandingToken.id))
        .join(Student, OutstandingToken.user_id == Student.id)
        .filter(Student.school_id == school_id, OutstandingToken.created_at >= since)
    )
    if until:
        q = q.filter(OutstandingToken.created_at < until)
    return q.scalar() or 0


def _active_student_count(db: Session, student_ids: list[int],
                          since: datetime, until: datetime | None) -> int:
    q = db.query(func.count(Student.id)).filter(
        Student.id.in_(student_ids),
        Student.last_login >= since,
    )
    if until:
        q = q.filter(Student.last_login < until)
    return q.scalar() or 0
