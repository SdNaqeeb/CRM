"""
Test Prep API client — calls quizmode.smartlearners.ai to generate
bridge-based MCQ challenges for inactive students.

Flow:
  1. Resolve student's class_num from DB
  2. Pick a random subject (MATHEMATICS / PHYSICS)
  3. Fetch available chapters for that class+subject
  4. Pick 1 random chapter
  5. Call /api/v1/generate-questions → get 5 MCQs
"""
import random
import logging
from typing import Dict, Any, Optional

import requests
from sqlalchemy.orm import Session

from models.django_tables import Student, Classes

logger = logging.getLogger(__name__)

TESTPREP_BASE_URL = "https://quizmode.smartlearners.ai"
SUBJECTS = ["MATHEMATICS", "PHYSICS"]
QUESTIONS_PER_CHAPTER = 5
REQUEST_TIMEOUT = 60  # seconds — MCQ generation can be slow (Gemini AI call)


def _get_student_class_num(student: Student, db: Session) -> Optional[int]:
    """Resolve the student's class number from class_name_id."""
    if not student.class_name_id:
        return None
    cls = db.query(Classes.class_name).filter(Classes.id == student.class_name_id).first()
    if not cls or not cls[0]:
        return None
    try:
        return int(cls[0])
    except (ValueError, TypeError):
        logger.warning("Cannot parse class_name '%s' as int for student %d", cls[0], student.id)
        return None


def _fetch_chapters(class_num: int, subject: str) -> Optional[list[str]]:
    """GET /api/v1/classes/{class_num}/chapters?subject={subject}"""
    url = f"{TESTPREP_BASE_URL}/api/v1/classes/{class_num}/chapters"
    try:
        resp = requests.get(url, params={"subject": subject}, timeout=15)
        if resp.status_code == 200:
            data = resp.json()
            chapters = data.get("chapters", [])
            if chapters:
                return chapters
            logger.warning("No chapters returned for class=%d subject=%s", class_num, subject)
            return None
        elif resp.status_code == 404:
            logger.info("No chapters found for class=%d subject=%s (404)", class_num, subject)
            return None
        else:
            logger.error("Fetch chapters failed: status=%d body=%s", resp.status_code, resp.text[:200])
            return None
    except requests.exceptions.RequestException as e:
        logger.error("Fetch chapters network error: %s", e)
        return None


def _generate_questions(class_num: int, subject: str, chapters: list[str]) -> Optional[Dict[str, Any]]:
    """POST /api/v1/generate-questions"""
    url = f"{TESTPREP_BASE_URL}/api/v1/generate-questions"
    payload = {
        "class_num": class_num,
        "subject": subject,
        "chapters": chapters,
        "questions_per_chapter": QUESTIONS_PER_CHAPTER,
    }
    try:
        resp = requests.post(url, json=payload, timeout=REQUEST_TIMEOUT)
        if resp.status_code == 200:
            return resp.json()
        else:
            logger.error("Generate questions failed: status=%d body=%s",
                         resp.status_code, resp.text[:300])
            return None
    except requests.exceptions.RequestException as e:
        logger.error("Generate questions network error: %s", e)
        return None


def generate_challenge_for_student(student: Student, db: Session) -> Optional[Dict[str, Any]]:
    """Main entry point — generate a 5-question MCQ challenge for a student.

    Returns the full test prep response dict on success, or None on failure.
    """
    name = student.fullname or student.username or f"Student #{student.id}"

    # 1. Get class_num
    class_num = _get_student_class_num(student, db)
    if not class_num:
        logger.warning("Skipping challenge for %s (id=%d): no class found", name, student.id)
        return None

    # 2. Try subjects in random order
    subjects = SUBJECTS.copy()
    random.shuffle(subjects)

    for subject in subjects:
        # 3. Fetch available chapters
        chapters = _fetch_chapters(class_num, subject)
        if not chapters:
            logger.info("No chapters for class=%d subject=%s, trying next subject", class_num, subject)
            continue

        # 4. Pick 1 random chapter
        selected_chapter = random.choice(chapters)
        logger.info("Generating challenge for %s (id=%d): class=%d, subject=%s, chapter=%s",
                     name, student.id, class_num, subject, selected_chapter)

        # 5. Generate questions
        result = _generate_questions(class_num, subject, [selected_chapter])
        if result and result.get("questions"):
            logger.info("Challenge generated for %s: %d questions (test_id=%s)",
                         name, len(result["questions"]), result.get("test_id", "?"))
            return result
        else:
            logger.warning("Question generation returned empty for class=%d subject=%s chapter=%s",
                           class_num, subject, selected_chapter)
            continue

    logger.error("Failed to generate challenge for %s (id=%d) — all subjects/chapters exhausted",
                 name, student.id)
    return None
