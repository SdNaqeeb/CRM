"""
Intervention service — automatically sends WhatsApp alerts and challenge
notifications to students at specific inactivity milestones (3, 7, 14 days).

Logic:
  - Day 3  → first alert + challenge notification + generate MCQs
  - Day 7  → second alert + challenge notification + generate MCQs
  - Day 14 → final alert + challenge notification + generate MCQs
  - If student logs back in and goes inactive again, cycle resets.
"""
import json
import logging
from datetime import datetime, timezone
from typing import Dict, Any

from sqlalchemy.orm import Session
from sqlalchemy import and_

from models.django_tables import Student, InterventionLog
from services.whatsapp_service import send_whatsapp_message, send_challenge_notification
from services.testprep_service import generate_challenge_for_student

logger = logging.getLogger(__name__)

# Milestones: send notifications only on these exact day thresholds
MILESTONES = [3, 7, 14]


def _get_milestone(days_inactive: int) -> int | None:
    """Return the milestone that matches, or None if no milestone applies.

    Day 3-6   → milestone 3
    Day 7-13  → milestone 7
    Day 14+   → milestone 14
    """
    if days_inactive >= 14:
        return 14
    if days_inactive >= 7:
        return 7
    if days_inactive >= 3:
        return 3
    return None


def _already_sent(db: Session, student_id: int, milestone: int,
                  last_login: datetime | None) -> bool:
    """Check if we already sent an intervention for this milestone
    since the student's last login.  If the student logs in and goes
    inactive again, last_login changes → we send again."""
    query = db.query(InterventionLog).filter(
        and_(
            InterventionLog.student_id == student_id,
            InterventionLog.day_milestone == milestone,
            InterventionLog.intervention_type == "alert",
        )
    )
    if last_login:
        query = query.filter(InterventionLog.last_login_at == last_login)
    else:
        query = query.filter(InterventionLog.last_login_at.is_(None))

    return query.first() is not None


def _log_intervention(db: Session, student_id: int, intervention_type: str,
                      milestone: int, days_inactive: int, phone: str | None,
                      last_login: datetime | None, success: bool,
                      detail: str = "") -> None:
    """Write a record to crm_intervention_log."""
    log = InterventionLog(
        student_id=student_id,
        intervention_type=intervention_type,
        day_milestone=milestone,
        days_inactive=days_inactive,
        whatsapp_success=success,
        phone_number=phone,
        detail=detail[:500] if detail else None,
        created_at=datetime.now(timezone.utc),
        last_login_at=last_login,
    )
    db.add(log)


def _process_student(student: Student, days_inactive: int, milestone: int,
                     db: Session) -> Dict[str, Any]:
    """Handle one inactive student: send alert, generate challenge, send notification."""
    name = student.fullname or student.username or f"Student #{student.id}"
    result = {
        "student_id": student.id,
        "name": name,
        "days_inactive": days_inactive,
        "milestone": milestone,
        "alert_sent": False,
        "challenge_generated": False,
        "challenge_notification_sent": False,
        "challenge_subject": None,
        "challenge_chapter": None,
        "challenge_questions": 0,
    }

    logger.info("Student %s (id=%d) inactive %d days → milestone %d, sending...",
                name, student.id, days_inactive, milestone)

    # ── 1. Send WhatsApp alert ──
    alert_result = send_whatsapp_message(
        phone=student.phone_number,
        message="",
        student_name=name,
    )
    alert_success = alert_result.get("success", False)
    result["alert_sent"] = alert_success
    _log_intervention(
        db, student.id, "alert", milestone, days_inactive,
        student.phone_number, student.last_login,
        success=alert_success,
        detail=alert_result.get("error", "sent"),
    )

    # ── 2. Generate MCQ challenge via test prep API ──
    challenge_data = generate_challenge_for_student(student, db)
    if challenge_data and challenge_data.get("questions"):
        result["challenge_generated"] = True
        result["challenge_subject"] = challenge_data.get("subject",
                                        # extract from response if available
                                        challenge_data.get("chapters", [""])[0] if challenge_data.get("chapters") else None)
        result["challenge_chapter"] = challenge_data.get("chapters", [None])[0]
        result["challenge_questions"] = len(challenge_data["questions"])

        # Store the full challenge response as detail (for later notification use)
        challenge_detail = json.dumps({
            "test_id": challenge_data.get("test_id"),
            "class_num": challenge_data.get("class_num"),
            "chapters": challenge_data.get("chapters"),
            "total_questions": challenge_data.get("total_questions"),
        })
    else:
        challenge_detail = "challenge generation failed"

    _log_intervention(
        db, student.id, "challenge", milestone, days_inactive,
        student.phone_number, student.last_login,
        success=result["challenge_generated"],
        detail=challenge_detail,
    )

    # ── 3. Send "You have a new challenge" WhatsApp notification ──
    if result["challenge_generated"]:
        notif_result = send_challenge_notification(
            phone=student.phone_number,
            student_name=name,
        )
        result["challenge_notification_sent"] = notif_result.get("success", False)
    else:
        logger.warning("Skipping challenge notification for %s — no challenge was generated", name)

    return result


def run_intervention_check(db: Session) -> Dict[str, Any]:
    """Main entry point — called by the cron job or manual trigger.

    Returns a summary dict with counts of what was sent.
    """
    now = datetime.now(timezone.utc)
    logger.info("=== Intervention check started at %s ===", now.isoformat())

    # Fetch all students (is_student=True) across all schools
    students = db.query(Student).filter(Student.is_student == True).all()
    logger.info("Found %d students to check", len(students))

    summary = {
        "checked": len(students),
        "alerts_sent": 0,
        "challenges_generated": 0,
        "challenge_notifications_sent": 0,
        "skipped_already_sent": 0,
        "skipped_active": 0,
        "errors": 0,
        "details": [],
    }

    for student in students:
        # Calculate days since last login
        if student.last_login:
            days_inactive = (now - student.last_login).days
        else:
            days_inactive = 999

        # Determine which milestone this student is at
        milestone = _get_milestone(days_inactive)
        if milestone is None:
            summary["skipped_active"] += 1
            continue

        # Check if we already sent for this milestone + login cycle
        if _already_sent(db, student.id, milestone, student.last_login):
            summary["skipped_already_sent"] += 1
            continue

        # Process this student
        try:
            result = _process_student(student, days_inactive, milestone, db)

            # Commit IMMEDIATELY after each student so that:
            # 1. _already_sent() works correctly for subsequent checks
            # 2. Other workers see the log and skip this student
            db.commit()

            summary["details"].append(result)

            if result["alert_sent"]:
                summary["alerts_sent"] += 1
            if result["challenge_generated"]:
                summary["challenges_generated"] += 1
            if result["challenge_notification_sent"]:
                summary["challenge_notifications_sent"] += 1
        except Exception as e:
            db.rollback()
            name = student.fullname or student.username or f"Student #{student.id}"
            logger.error("Error processing student %s (id=%d): %s", name, student.id, e, exc_info=True)
            summary["errors"] += 1

    logger.info(
        "=== Intervention check complete: %d alerts, %d challenges generated, %d notifications sent ===",
        summary["alerts_sent"], summary["challenges_generated"], summary["challenge_notifications_sent"],
    )
    return summary
