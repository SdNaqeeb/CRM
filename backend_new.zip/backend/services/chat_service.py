"""Chat service – interprets natural-language queries using Gemini,
calls existing cached CRM API endpoints internally, and returns
conversational responses."""

import json
import logging
import re as _re
from typing import Any

import requests
from sqlalchemy.orm import Session

from config import GEMINI_API_KEY, AI_MODEL
from google import genai
from google.genai import types
from services.improvement_service import get_school_improvement
from services.chat_queries import (
    get_subject_performance,
    get_student_deep_dive,
    get_grade_performance,
    get_student_inactivity_reason,
    get_homework_stats,
    get_exam_analysis,
    get_bottom_performers,
    get_period_improvement,
    get_class_exam_improvement,
    get_compare_classes,
)

logger = logging.getLogger(__name__)

client = genai.Client(api_key=GEMINI_API_KEY)

# Base URL for internal API calls (same backend)
_INTERNAL = "http://127.0.0.1:8000"

# ── Gemini helpers ──────────────────────────────────────────────────────────

CHAT_MODEL = "gemini-2.0-flash"  # Fast model for chat responses


def _call_gemini(system: str, user_text: str, json_mode: bool = False,
                 temperature: float = 0.3) -> str:
    """Thin wrapper around Gemini – returns raw text."""
    config = types.GenerateContentConfig(
        system_instruction=system,
        temperature=temperature,
    )
    if json_mode:
        config.response_mime_type = "application/json"

    response = client.models.generate_content(
        model=CHAT_MODEL,
        contents=[types.Content(
            role="user",
            parts=[types.Part.from_text(text=user_text)],
        )],
        config=config,
    )
    return response.text.strip()


# ── Intent classification ───────────────────────────────────────────────────

def _parse_days(msg: str, default: int = 14) -> int:
    """Extract a day count from message text."""
    m = _re.search(r'(\d+)\s*day', msg)
    if m:
        return min(int(m.group(1)), 365)
    m = _re.search(r'(\d+)\s*week', msg)
    if m:
        return min(int(m.group(1)) * 7, 365)
    m = _re.search(r'(\d+)\s*month', msg)
    if m:
        return min(int(m.group(1)) * 30, 365)
    if "week" in msg:
        return 7
    if "month" in msg:
        return 30
    return default


def _extract_subject(msg: str) -> str | None:
    """Try to extract a subject name from the message."""
    subjects = [
        "math", "maths", "mathematics", "science", "physics", "chemistry",
        "biology", "english", "hindi", "social", "history", "geography",
        "computer", "economics", "accounts", "accountancy",
    ]
    for s in subjects:
        if s in msg:
            return s
    return None


def _extract_grade_section(msg: str) -> tuple[str | None, str | None]:
    """Try to extract grade and section from message."""
    grade = None
    section = None

    # "class 8", "grade 8", "8th"
    m = _re.search(r'(?:class|grade)\s*(\d+)', msg)
    if m:
        grade = m.group(1)
    else:
        m = _re.search(r'(\d+)(?:th|st|nd|rd)\s*(?:class|grade)?', msg)
        if m:
            grade = m.group(1)

    # "section A", "sec B"
    m = _re.search(r'(?:section|sec)\s*([a-zA-Z])', msg)
    if m:
        section = m.group(1).upper()

    return grade, section


def _classify_intent(message: str, role: str) -> dict:
    """Fast keyword-based intent classifier — no AI call needed."""
    msg = message.lower().strip()

    # Help
    if msg in ("help", "what can you do", "what can you do?", "commands") or "what can" in msg:
        return {"intent": "help", "params": {}}

    # Send alert
    if any(k in msg for k in ("send alert", "send notification", "notify student", "whatsapp")):
        return {"intent": "send_alert_intent", "params": {}}

    # Compare classes
    if any(k in msg for k in ("compare class", "compare grade", "across class", "class comparison",
                               "all classes", "class wise", "classwise", "class-wise",
                               "which class is", "best class", "worst class",
                               "classes performing", "grade comparison", "across grade")):
        return {"intent": "compare_classes", "params": {"days": _parse_days(msg, 14)}}

    # Compare schools
    if any(k in msg for k in ("compare school", "compare engagement", "across school", "school comparison", "all schools")):
        return {"intent": "compare_schools", "params": {}}

    # Why inactive — "why is X inactive", "why isn't X logging in"
    if any(k in msg for k in ("why inactive", "why is", "why isn't", "reason for inactiv")):
        name_m = _re.search(r'why\s+(?:is|isn\'t|isnt)\s+(.+?)\s+(?:inactive|not)', msg)
        name = name_m.group(1).strip() if name_m else None
        return {"intent": "student_inactive_reason", "params": {"name": name}}

    # Inactive students
    if "inactive" in msg or "haven't logged" in msg or "not logged" in msg or "never logged" in msg:
        return {"intent": "inactive_students", "params": {}}

    # At-risk students
    if any(k in msg for k in ("at risk", "at-risk", "atrisk", "low engagement", "struggling", "dropping")):
        return {"intent": "at_risk_students", "params": {}}

    # Bottom performers / lowest scoring
    if any(k in msg for k in ("bottom performer", "lowest score", "lowest scoring",
                               "weakest student", "worst performing", "bottom student",
                               "scoring lowest", "struggling student")):
        return {"intent": "bottom_performers", "params": {"days": _parse_days(msg, 30)}}

    # Top performers
    if any(k in msg for k in ("top performer", "most active", "best student", "top student", "highest")):
        return {"intent": "top_performers", "params": {}}

    # Subject performance — "how are students doing in math"
    subject = _extract_subject(msg)
    if subject and any(k in msg for k in ("doing in", "performance in", "scores in",
                                           "how is", "how are", "subject")):
        return {"intent": "subject_performance", "params": {"subject": subject, "days": _parse_days(msg, 30)}}

    # Grade/section performance — "how is class 8 doing"
    grade, section = _extract_grade_section(msg)
    if grade and any(k in msg for k in ("doing", "performance", "how is", "how are", "performing")):
        return {"intent": "grade_performance", "params": {"grade": grade, "section": section, "days": _parse_days(msg, 30)}}

    # Exam analysis — "how did students do on exams", "exam results"
    if any(k in msg for k in ("exam result", "exam performance", "exam analysis",
                               "how did students do on", "last exam", "exam score")):
        return {"intent": "exam_analysis", "params": {"days": _parse_days(msg, 30)}}

    # Homework stats — "homework completion", "how many submitted homework"
    if any(k in msg for k in ("homework completion", "homework rate", "submitted homework",
                               "homework submission", "homework stat")):
        return {"intent": "homework_stats", "params": {"days": _parse_days(msg, 7)}}

    # Activity overview (general activity/submissions/homework/classwork/exams)
    if any(k in msg for k in ("activity", "submissions", "homework", "classwork", "exams")):
        return {"intent": "activity_overview", "params": {"days": _parse_days(msg)}}

    # Improvement / period comparison
    if any(k in msg for k in ("improvement", "improved", "progress", "compared to last",
                               "this week vs", "week over week", "better than last",
                               "worse than last", "getting better", "getting worse",
                               "this month vs", "month over month")):
        days = _parse_days(msg, 7)
        # "compared to last month" / "month over month" → 30 day comparison
        if "month" in msg:
            days = 30
        return {"intent": "improvement", "params": {"days": days}}

    # Engagement trend
    if any(k in msg for k in ("trend", "improving", "declining")):
        return {"intent": "engagement_trend", "params": {}}

    # Student search / deep dive — "tell me about <name>", "full report on <name>"
    is_deep_dive = any(k in msg for k in ("full report", "deep dive", "detailed report",
                                           "everything about", "complete report"))
    name_patterns = [
        r"(?:about|find|search|look up|status of|how is|how's|report on|report for)\s+(.+?)[\?\.]?$",
        r"^(.+?)(?:'s| status| engagement| details| info| report)",
    ]
    for pat in name_patterns:
        m = _re.search(pat, msg)
        if m:
            name = m.group(1).strip().strip("\"'")
            skip = {"student", "students", "school", "schools", "teacher", "teachers",
                    "engagement", "dashboard", "activity", "the", "my", "all", "a",
                    "class", "grade", "section", "homework", "exam"}
            if name and name not in skip and len(name) > 1:
                intent = "student_deep_dive" if is_deep_dive else "student_search"
                return {"intent": intent, "params": {"name": name}}

    # Dashboard summary (broad catch)
    if any(k in msg for k in ("dashboard", "summary", "overview", "how are", "metrics", "stats",
                               "how many", "total student", "how's everything")):
        return {"intent": "dashboard_summary", "params": {}}

    # Unknown intent — don't guess
    return {"intent": "unknown", "params": {}}


# ── Data fetchers (call existing cached API endpoints) ──────────────────────

def _api_get(path: str) -> Any:
    """GET an internal API path, return parsed JSON or None."""
    try:
        r = requests.get(f"{_INTERNAL}{path}", timeout=120)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        logger.warning(f"Internal API call failed {path}: {e}")
        return None


def _fetch_dashboard(role: str, school_code: str | None,
                     username: str | None, school_id: int | None) -> dict | None:
    """Fetch the appropriate dashboard data using existing cached endpoints."""
    if role == "orcalex_admin":
        return _api_get("/api/dashboard/orcalex/all")
    if role == "teacher" and username:
        return _api_get(f"/api/dashboard/teacher/by-username/{username}")
    if school_code:
        return _api_get(f"/api/dashboard/school/by-code/{school_code}")
    if school_id:
        return _api_get(f"/api/dashboard/school/{school_id}")
    return None


def _extract_summary(dash: dict, role: str) -> dict:
    """Pull key metrics from dashboard response for the bot."""
    if not dash:
        return {"error": "Could not load dashboard data."}

    base = {
        "total_students": dash.get("total_students", 0),
        "active_this_week": dash.get("active_this_week") or dash.get("active_students", 0),
        "at_risk": dash.get("at_risk_count") or dash.get("at_risk_students", 0),
        "inactive": dash.get("inactive_count") or dash.get("inactive_students", 0),
    }
    if role == "orcalex_admin":
        base["total_schools"] = dash.get("total_schools", 0)
        base["total_teachers"] = dash.get("total_teachers", 0)
        base["total_sessions_this_week"] = dash.get("total_sessions_this_week", 0)
    return base


def _extract_at_risk(dash: dict, status_filter: str) -> list[dict]:
    """Extract at-risk / inactive students from dashboard data."""
    if not dash:
        return []

    students = dash.get("students") or dash.get("all_students") or []
    target = {"at_risk", "low_engagement", "inactive"} if status_filter == "at_risk" else {status_filter}

    filtered = []
    for s in students:
        st = s.get("engagement_status", "")
        if st in target:
            filtered.append({
                "name": s.get("full_name", "Unknown"),
                "grade": s.get("grade") or "N/A",
                "days_inactive": s.get("days_since_login"),
                "status": st,
                "last_login": s.get("last_login") or "Never",
            })

    filtered.sort(key=lambda x: x.get("days_inactive") or 0, reverse=True)
    return filtered[:20]


def _extract_student_by_name(dash: dict, name: str) -> list[dict]:
    """Search students in dashboard data by name."""
    if not dash:
        return []

    students = dash.get("students") or dash.get("all_students") or []
    query = name.lower()
    matches = []
    for s in students:
        fn = s.get("full_name", "")
        if query in fn.lower():
            matches.append({
                "name": fn,
                "student_id": s.get("student_id"),
                "grade": s.get("grade") or "N/A",
                "section": s.get("section") or "N/A",
                "days_inactive": s.get("days_since_login"),
                "status": s.get("engagement_status", "unknown"),
                "last_login": s.get("last_login") or "Never",
                "sessions_this_week": s.get("sessions_this_week", 0),
                "total_sessions": s.get("total_sessions", 0),
            })
    return matches[:10]


def _extract_top_performers(dash: dict) -> list[dict]:
    """Get most active students from dashboard data."""
    if not dash:
        return []

    students = dash.get("students") or dash.get("all_students") or []
    active = [
        {
            "name": s.get("full_name", "Unknown"),
            "grade": s.get("grade") or "N/A",
            "sessions_this_week": s.get("sessions_this_week", 0),
            "total_sessions": s.get("total_sessions", 0),
            "status": s.get("engagement_status", ""),
        }
        for s in students
        if s.get("engagement_status") == "active"
    ]
    active.sort(key=lambda x: x["sessions_this_week"], reverse=True)
    return active[:10]


def _extract_school_comparison(dash: dict) -> list[dict]:
    """Extract school comparison from OrcaLex dashboard."""
    if not dash:
        return []
    schools = dash.get("schools", [])
    return [
        {
            "name": sc.get("school_name", ""),
            "students": sc.get("total_students", 0),
            "teachers": sc.get("total_teachers", 0),
            "active": sc.get("active_this_week", 0),
            "at_risk": sc.get("at_risk_count", 0),
            "inactive": sc.get("inactive_count", 0),
            "sessions": sc.get("total_sessions_this_week", 0),
            "trend": sc.get("engagement_trend", "stable"),
        }
        for sc in schools
    ]


def _fetch_activity(school_id: int | None, days: int = 14) -> dict | None:
    """Fetch activity overview for a school."""
    if not school_id:
        return None
    return _api_get(f"/api/activity/school/{school_id}?days={days}")


def _find_student_id_by_name(dash: dict, name: str) -> int | None:
    """Find a student ID from dashboard data by name match."""
    if not dash or not name:
        return None
    students = dash.get("students") or dash.get("all_students") or []
    query = name.lower()
    for s in students:
        fn = s.get("full_name", "")
        if query in fn.lower():
            return s.get("student_id")
    return None


# ── Response formatter ──────────────────────────────────────────────────────

RESPONSE_SYSTEM = """\
You are a helpful CRM assistant for Smartlearners.ai, an education platform.
Given the user's question and CRM data, compose a clear, concise, friendly response.

Rules:
- Use markdown tables whenever displaying lists of students, schools, subjects, or any structured data with multiple fields
- Use ## for section headings when there are multiple sections
- Use **bold** for key numbers
- Show ALL items in the table — never truncate or hide rows
- Keep text summaries short: 1-2 sentences before the table
- Use numbers and percentages
- If data is empty, say so helpfully
- Be conversational but professional
- Do NOT suggest follow-up questions at the end
"""


# Follow-up questions per role — only questions that the role can actually answer.
# teacher: has school context via school_code, sees own students
# school_admin: has school_id, can query all school-level data
# orcalex_admin: NO school_id, can only see cross-school/dashboard-level data
FOLLOWUP_QUESTIONS: dict[str, list[str]] = {
    "teacher": [
        "How are my students doing?",
        "Which students are at risk?",
        "Show inactive students",
        "Who are the most active students?",
        "Which students are scoring lowest?",
        "How are students doing in Math?",
        "How many submitted homework this week?",
        "What is the improvement this week?",
        "How did students do on exams?",
        "How is Class 8 doing?",
    ],
    "school_admin": [
        "Dashboard summary",
        "Compare classes performance",
        "Which students are at risk?",
        "Show inactive students",
        "Who are the most active students?",
        "Which students are scoring lowest?",
        "How is Class 8 doing?",
        "How did students do on exams?",
        "How many submitted homework this week?",
        "What is the improvement this week?",
        "How are students doing in Science?",
    ],
    "orcalex_admin": [
        "Compare engagement across schools",
        "Dashboard summary",
        "Which students are at risk?",
        "Show inactive students",
        "Who are the most active students?",
        "Is engagement improving?",
    ],
}


def _pick_followups(role: str, exclude_message: str) -> str:
    """Pick 2 random follow-up questions for the role, excluding similar to current query."""
    import random
    pool = FOLLOWUP_QUESTIONS.get(role, FOLLOWUP_QUESTIONS["teacher"])
    # Filter out questions too similar to what was just asked
    exclude_lower = exclude_message.lower()
    filtered = [q for q in pool if q.lower() not in exclude_lower and exclude_lower not in q.lower()]
    if len(filtered) < 2:
        filtered = pool
    chosen = random.sample(filtered, min(2, len(filtered)))
    return "\n\nYou might also want to ask:\n" + "\n".join(f"- {q}" for q in chosen)


IMPROVEMENT_PLAN_SYSTEM = """\
You are a CRM assistant for Smartlearners.ai, generating improvement reports for school teachers.
Given CRM data about a specific class's performance, generate a clear, data-focused report.

The data contains two periods:
- "current" = the recent period the teacher asked about (e.g. last 2 weeks, last 5 weeks)
- "previous" = the same-length period right before that, used for comparison

When displaying these in the table, use the actual date ranges from the "period" field in the data (e.g. "11 Mar – 25 Mar" and "25 Feb – 11 Mar"), NOT the words "current" or "previous".

Format rules:
- Use markdown formatting for readability
- Use ## for section headings
- Use markdown tables for data
- Use **bold** for key numbers
- Keep it concise and factual — teachers want data, not advice

Content rules:
- Start with a ## Summary (2-3 sentences: total students, active vs inactive, overall trend)
- Add a ## Key Metrics table with columns: Metric | <recent date range> | <previous date range> | Change (%)
  Include rows: Practice Count, Homework Count, Active Students
- If exam data exists (exam_count > 0), add a ## Exam Performance table with columns: Exam Name | Type | Avg % | Students Appeared | Date
- Add a ## Weak Subjects section as a table: Subject | Submissions | Avg %
- Add a ## Struggling Students section: show count and their average %, do NOT list names
- Do NOT include any action plan, recommendations, or suggestions
- Do NOT include follow-up questions
- Keep the tone professional and data-driven
"""


def _format_improvement_plan(user_message: str, data: Any) -> str:
    """Format improvement plan data into an actionable response via Gemini."""
    try:
        data_str = json.dumps(data, default=str, ensure_ascii=False)
        if len(data_str) > 4000:
            data_str = data_str[:4000] + "... (truncated)"

        prompt = f"User query: {user_message}\n\nClass Improvement Data:\n{data_str}"
        return _call_gemini(IMPROVEMENT_PLAN_SYSTEM, prompt, temperature=0.4)
    except Exception as e:
        logger.warning(f"Improvement plan formatting failed: {e}")
        # Fallback
        grade = data.get("grade", "?")
        total = data.get("total_students", 0)
        active = data.get("active_in_period", 0)
        return (
            f"Class {grade} Overview ({data.get('timeline_days', 14)} days):\n"
            f"Total students: {total}, Active: {active}, Inactive: {total - active}\n"
            f"Please try again for a detailed improvement plan."
        )


def _format_response(user_message: str, intent: str, data: Any) -> str:
    try:
        data_str = json.dumps(data, default=str, ensure_ascii=False)
        if len(data_str) > 3000:
            data_str = data_str[:3000] + "... (truncated)"

        return _call_gemini(
            RESPONSE_SYSTEM,
            f"User question: {user_message}\nIntent: {intent}\nCRM Data:\n{data_str}",
            temperature=0.4,
        )
    except Exception as e:
        logger.warning(f"Response formatting failed: {e}")
        # Fallback: return raw data summary
        if isinstance(data, dict):
            lines = [f"{k}: {v}" for k, v in data.items() if k != "error"]
            return "\n".join(lines) if lines else str(data.get("error", "No data available."))
        return str(data)[:500]


# ── Follow-up resolution ──────────────────────────────────────────────────

def _is_followup(message: str) -> bool:
    """Check if the message is a short follow-up or contextual reference."""
    msg = message.lower().strip().rstrip("!.?")
    # Exact match follow-ups
    exact = {
        "yes", "yeah", "yep", "sure", "ok", "okay", "please", "go ahead",
        "show me", "show them", "list them", "list it", "tell me",
        "do it", "yes please", "yea", "ya", "y", "show", "list",
        "go on", "continue", "more", "details", "elaborate",
        "what about that", "and then", "anything else",
    }
    if msg in exact:
        return True
    # Short contextual messages that reference prior conversation
    if len(msg.split()) <= 6 and any(k in msg for k in (
        "what about", "how about", "and for", "show me", "tell me more",
        "can you", "which ones", "like what", "for example",
    )):
        return True
    return False


def _resolve_followup(message: str, chat_history: list[dict] | None) -> str | None:
    """If the message is a follow-up, use Gemini with chat history to resolve."""
    if not chat_history or len(chat_history) < 2:
        return None
    if not _is_followup(message):
        return None

    # Build conversation context from history
    history_text = ""
    for h in chat_history[:-1]:  # exclude current message
        role_label = "User" if h["sender"] == "user" else "Assistant"
        # Truncate long bot responses for context
        text = h["text"][:300] if h["sender"] == "bot" else h["text"]
        history_text += f"{role_label}: {text}\n"

    resolve_prompt = (
        "Given this conversation history and the user's latest message, "
        "rewrite the user's latest message as a clear, standalone query "
        "that captures what they are asking for. Return ONLY the rewritten query, nothing else.\n\n"
        f"Conversation:\n{history_text}"
        f"User: {message}\n\n"
        "Rewritten query:"
    )

    try:
        resolved = _call_gemini(
            "You rewrite ambiguous follow-up messages into clear standalone queries based on conversation context.",
            resolve_prompt,
            temperature=0.1,
        )
        logger.info(f"Follow-up resolved: '{message}' → '{resolved}'")
        return resolved.strip()
    except Exception as e:
        logger.warning(f"Follow-up resolution failed: {e}")
        return None


# ── Main entry point ────────────────────────────────────────────────────────

HELP_TEXT = (
    "I can help you with:\n\n"
    "📋 Dashboard summary – \"How are my students doing?\"\n"
    "📈 Weekly improvement – \"What is the improvement this week?\"\n"
    "⚠️ At-risk students – \"Which students are at risk?\"\n"
    "🔴 Inactive students – \"Who hasn't logged in recently?\"\n"
    "❓ Why inactive – \"Why is Rahul inactive?\"\n"
    "🔍 Student search – \"Tell me about Rahul\"\n"
    "📊 Full student report – \"Give me a full report on Priya\"\n"
    "📚 Subject performance – \"How are students doing in Math?\"\n"
    "🏫 Grade performance – \"How is Class 8 Section A doing?\"\n"
    "📝 Homework stats – \"How many students submitted homework?\"\n"
    "🎯 Exam analysis – \"How did students do on the last exam?\"\n"
    "⭐ Top performers – \"Who are the most active students?\"\n"
    "📉 Bottom performers – \"Which students are scoring lowest?\"\n"
    "🏫 Compare classes – \"Compare classes performance\" (school admin)\n"
    "🔄 Compare schools – \"Compare engagement across schools\" (admin)\n"
    "📊 Engagement trends – \"Is engagement improving?\"\n"
    "📆 Activity overview – \"Activity overview this week\"\n\n"
    "Just ask in plain English!"
)


def process_chat_message(
    message: str,
    role: str,
    school_id: int | None,
    school_code: str | None,
    username: str | None,
    db: Session,
    dashboard_data: dict | None = None,
    chat_history: list[dict] | None = None,
    class_name: str | None = None,
    exam_type: str | None = None,
    timeline_days: int | None = None,
) -> str:
    """Process a chat message: classify intent → fetch data → format response."""
    reply = _process_chat_inner(
        message, role, school_id, school_code, username, db,
        dashboard_data, chat_history, class_name, exam_type, timeline_days,
    )
    # Append 2 random follow-up suggestions (skip for help/unknown)
    if reply and reply != HELP_TEXT and "I'm not sure how to answer" not in reply:
        reply += _pick_followups(role, message)
    return reply


def _process_chat_inner(
    message: str, role: str, school_id: int | None,
    school_code: str | None, username: str | None, db: Session,
    dashboard_data: dict | None, chat_history: list[dict] | None,
    class_name: str | None, exam_type: str | None, timeline_days: int | None,
) -> str:
    """Inner handler — returns reply without follow-up suggestions."""

    # Resolve school_id from school_code if needed
    if not school_id and school_code:
        from models.django_tables import School
        school = db.query(School).filter(School.code == school_code).first()
        if school:
            school_id = school.id

    # ── Improvement Plan mode (structured form submission) ──
    if class_name:
        if not school_id:
            return "I need a school context to generate an improvement plan."
        # Parse timeline from message text (e.g. "in the last 3 weeks")
        days = timeline_days or _parse_days(message, default=14)
        data = get_class_exam_improvement(school_id, db, grade=class_name,
                                          exam_type=exam_type, days=days)
        if data.get("error"):
            return data["error"]
        return _format_improvement_plan(message, data)

    # Check if this is a follow-up message and resolve it
    resolved = _resolve_followup(message, chat_history)
    if resolved:
        message = resolved

    # Step 1: classify intent
    classified = _classify_intent(message, role)
    intent = classified.get("intent", "general")
    params = classified.get("params", {})
    logger.info(f"Chat intent={intent}, params={params}, role={role}")

    # Step 2: fetch data from existing cached endpoints
    if intent == "help":
        return HELP_TEXT

    if intent == "send_alert_intent":
        return (
            "I can't send alerts directly from the chat yet. "
            "To send WhatsApp alerts, use the Send Alert button in the student table — "
            "you can select multiple students and send bulk alerts too!"
        )

    # Use pre-loaded dashboard data from frontend if available,
    # otherwise fetch from internal API
    dash = dashboard_data if dashboard_data else _fetch_dashboard(role, school_code, username, school_id)

    # ── Dashboard summary ──
    if intent == "dashboard_summary":
        data = _extract_summary(dash, role)
        return _format_response(message, intent, data)

    # ── At-risk / Inactive students ──
    if intent in ("at_risk_students", "inactive_students"):
        status_filter = "inactive" if intent == "inactive_students" else "at_risk"
        students = _extract_at_risk(dash, status_filter)
        return _format_response(message, intent, {"students": students, "count": len(students)})

    # ── Student search (basic) ──
    if intent == "student_search":
        name = params.get("name", "")
        if not name:
            return "Please provide a student name to search for."
        matches = _extract_student_by_name(dash, name)
        # If exactly one match, auto-upgrade to deep dive
        if len(matches) == 1 and school_id:
            sid = matches[0].get("student_id")
            if sid:
                data = get_student_deep_dive(sid, db)
                return _format_response(message, "student_deep_dive", data)
        return _format_response(message, intent, {"matches": matches, "count": len(matches)})

    # ── Student deep dive ──
    if intent == "student_deep_dive":
        name = params.get("name", "")
        if not name:
            return "Please provide a student name for the report."
        sid = _find_student_id_by_name(dash, name)
        if not sid:
            return f"I couldn't find a student matching '{name}'. Try using their full name."
        data = get_student_deep_dive(sid, db)
        return _format_response(message, intent, data)

    # ── Why is student inactive? ──
    if intent == "student_inactive_reason":
        name = params.get("name")
        if not name:
            return "Please specify which student you'd like to know about. Example: \"Why is Rahul inactive?\""
        sid = _find_student_id_by_name(dash, name)
        if not sid:
            return f"I couldn't find a student matching '{name}'."
        data = get_student_inactivity_reason(sid, db)
        return _format_response(message, intent, data)

    # ── Subject performance ──
    if intent == "subject_performance":
        if not school_id:
            return "I need a school context for subject performance."
        subject = params.get("subject")
        days = params.get("days", 30)
        data = get_subject_performance(school_id, db, subject=subject, days=days)
        return _format_response(message, intent, data)

    # ── Grade/section performance ──
    if intent == "grade_performance":
        if not school_id:
            return "I need a school context for grade performance."
        grade = params.get("grade")
        section = params.get("section")
        days = params.get("days", 30)
        data = get_grade_performance(school_id, db, grade=grade, section=section, days=days)
        return _format_response(message, intent, data)

    # ── Homework stats ──
    if intent == "homework_stats":
        if not school_id:
            return "I need a school context for homework stats."
        days = params.get("days", 7)
        data = get_homework_stats(school_id, db, days=days)
        return _format_response(message, intent, data)

    # ── Exam analysis ──
    if intent == "exam_analysis":
        if not school_id:
            return "I need a school context for exam analysis."
        days = params.get("days", 30)
        data = get_exam_analysis(school_id, db, days=days)
        return _format_response(message, intent, data)

    # ── Bottom performers ──
    if intent == "bottom_performers":
        if not school_id:
            return "I need a school context for bottom performers."
        days = params.get("days", 30)
        data = get_bottom_performers(school_id, db, days=days)
        return _format_response(message, intent, data)

    # ── Activity overview ──
    if intent == "activity_overview":
        days = params.get("days", 14)
        if isinstance(days, str):
            try:
                days = int(days)
            except ValueError:
                days = 14
        data = _fetch_activity(school_id, days)
        if not data and role == "orcalex_admin":
            summary = _extract_summary(dash, role)
            return _format_response(message, intent, summary)
        if not data:
            return "I need a school context to fetch activity data. Please specify a school."
        return _format_response(message, intent, data)

    # ── Compare classes ──
    if intent == "compare_classes":
        if role not in ("school_admin", "orcalex_admin"):
            return "Class comparison is available for school admins only."
        if not school_id:
            return "I need a school context to compare classes."
        days = params.get("days", 14)
        data = get_compare_classes(school_id, db, days=days)
        return _format_response(message, intent, data)

    # ── Compare schools ──
    if intent == "compare_schools":
        if role not in ("orcalex_admin", "school_admin"):
            return "School comparison is available for admin users only."
        schools = _extract_school_comparison(dash)
        return _format_response(message, intent, {"schools": schools, "count": len(schools)})

    # ── Engagement trend ──
    if intent == "engagement_trend":
        data = _extract_summary(dash, role)
        if role == "orcalex_admin" and dash:
            schools = _extract_school_comparison(dash)
            data["school_trends"] = [
                {"name": s["name"], "trend": s["trend"]} for s in schools
            ]
        return _format_response(message, intent, data)

    # ── Improvement (flexible period) ──
    if intent == "improvement":
        if not school_id:
            return "I need a school context to compare improvement. Please specify a school."
        days = params.get("days", 7)
        if days == 7:
            # Use the existing week-over-week service for weekly
            data = get_school_improvement(school_id, db)
        else:
            # Use flexible period comparison for month/custom
            data = get_period_improvement(school_id, db, days=days)
        return _format_response(message, intent, data)

    # ── Top performers ──
    if intent == "top_performers":
        students = _extract_top_performers(dash)
        return _format_response(message, intent, {"students": students, "count": len(students)})

    # ── Unknown / fallback ──
    return (
        "I'm not sure how to answer that. I can help with:\n"
        "- Dashboard summary\n"
        "- Student engagement & activity\n"
        "- At-risk or inactive students\n"
        "- Subject/grade performance\n"
        "- Homework & exam stats\n"
        "- Improvement reports (use the filters above the input)\n\n"
        "Try rephrasing your question or type \"help\" for a full list."
    )
