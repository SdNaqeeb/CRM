"""
Core engagement calculation logic.
Uses last_login + GapAnalysis counts to determine engagement status.
"""
from datetime import datetime, timedelta, timezone
from sqlalchemy.orm import Session
from sqlalchemy import func

from models.django_tables import Student, GapAnalysis, Classes, Section, SubjectTeacherMapping, OutstandingToken, BlacklistedToken
from schemas.engagement import EngagementStatus, StudentEngagementSummary, EngagementAlert


def _week_start() -> datetime:
    """Monday 00:00 of the current week."""
    now = datetime.now(timezone.utc)
    return (now - timedelta(days=now.weekday())).replace(hour=0, minute=0, second=0, microsecond=0)


def _last_week_start() -> datetime:
    return _week_start() - timedelta(weeks=1)


def _compute_status(days_since_login: int | None, sessions_this_week: int) -> EngagementStatus:
    if days_since_login is None:
        return EngagementStatus.INACTIVE
    if days_since_login <= 3:
        return EngagementStatus.ACTIVE
    if days_since_login <= 7:
        return EngagementStatus.AT_RISK
    if days_since_login <= 14:
        return EngagementStatus.LOW_ENGAGEMENT
    return EngagementStatus.INACTIVE


def _has_active_token(student_id: int, db: Session, now: datetime) -> bool:
    """Check if user has at least one non-blacklisted, non-expired JWT token."""
    blacklisted_subq = (
        db.query(BlacklistedToken.token_id)
        .subquery()
    )

    active = (
        db.query(OutstandingToken.id)
        .filter(
            OutstandingToken.user_id == student_id,
            OutstandingToken.expires_at >= now,
            ~OutstandingToken.id.in_(db.query(blacklisted_subq))
        )
        .first()
    )
    return active is not None


def calculate_student_engagement(student: Student, db: Session, role_label: str = "student") -> StudentEngagementSummary:
    now = datetime.now(timezone.utc)
    week_start = _week_start()

    # Google-authenticated users (have google_sub) are considered active
    is_google_user = bool(student.google_sub)

    # days since login
    days_since_login = None
    last_login_str = None
    if student.last_login:
        delta = now - student.last_login
        days_since_login = delta.days
        last_login_str = student.last_login.isoformat()

    # JWT token-based session counts (each outstanding token = a login session)
    sessions_this_week = (
        db.query(func.count(OutstandingToken.id))
        .filter(
            OutstandingToken.user_id == student.id,
            OutstandingToken.created_at >= week_start,
        )
        .scalar()
    ) or 0

    total_sessions = (
        db.query(func.count(OutstandingToken.id))
        .filter(OutstandingToken.user_id == student.id)
        .scalar()
    ) or 0

    # Check if user has an active (non-blacklisted, non-expired) token
    has_active = _has_active_token(student.id, db, now)

    # Google-auth users with google_sub are always considered active
    if is_google_user:
        status = EngagementStatus.ACTIVE
        has_active = True
    else:
        status = _compute_status(days_since_login, sessions_this_week)

    # Resolve grade from class_name_id
    grade = None
    if student.class_name_id:
        cls = db.query(Classes.class_name).filter(Classes.id == student.class_name_id).first()
        if cls:
            grade = cls[0]

    # Resolve section name from section_ref_id
    section_name = student.section
    if not section_name and student.section_ref_id:
        sec = db.query(Section.name).filter(Section.id == student.section_ref_id).first()
        if sec:
            section_name = sec[0]

    return StudentEngagementSummary(
        student_id=student.id,
        user_id=student.id,
        full_name=student.fullname or student.username or "",
        email=student.email,
        grade=grade,
        section=section_name,
        last_login=last_login_str,
        days_since_login=days_since_login,
        total_sessions=total_sessions,
        sessions_this_week=sessions_this_week,
        engagement_status=status,
        has_active_alert=status in (EngagementStatus.AT_RISK, EngagementStatus.LOW_ENGAGEMENT, EngagementStatus.INACTIVE),
        is_currently_active=has_active,
        auth_provider="google" if is_google_user else "password",
        role=role_label,
    )


def get_engagements_for_users(users: list[Student], db: Session, role_label: str = "student") -> list[StudentEngagementSummary]:
    """Calculate engagement for an arbitrary list of users."""
    return [calculate_student_engagement(u, db, role_label=role_label) for u in users]


def get_all_student_engagements(school_id: int, db: Session) -> list[StudentEngagementSummary]:
    students = (
        db.query(Student)
        .filter(Student.school_id == school_id, Student.is_student == True)
        .all()
    )
    return get_engagements_for_users(students, db, role_label="student")


def get_all_teacher_engagements(school_id: int, db: Session) -> list[StudentEngagementSummary]:
    teachers = (
        db.query(Student)
        .filter(Student.school_id == school_id, Student.is_teacher == True)
        .all()
    )
    return get_engagements_for_users(teachers, db, role_label="teacher")


def get_google_auth_users(db: Session) -> list[StudentEngagementSummary]:
    """Get engagement summaries for Google-authenticated users (have google_sub, may have no school)."""
    google_users = (
        db.query(Student)
        .filter(
            Student.google_sub.isnot(None),
            Student.google_sub != "",
            Student.school_id.is_(None),
        )
        .all()
    )
    return get_engagements_for_users(google_users, db, role_label="google_user")


def get_teacher_section_students(teacher_username: str, db: Session) -> tuple[Student | None, list[StudentEngagementSummary]]:
    """
    Find teacher by username, look up their section mappings,
    return students in those sections.
    """
    teacher = (
        db.query(Student)
        .filter(Student.username == teacher_username, Student.is_teacher == True)
        .first()
    )
    if not teacher:
        return None, []

    # Get section IDs from SubjectTeacherMapping
    section_ids = (
        db.query(SubjectTeacherMapping.section_id)
        .filter(SubjectTeacherMapping.teacher_id == teacher.id)
        .distinct()
        .all()
    )
    section_ids = [s[0] for s in section_ids if s[0] is not None]

    if not section_ids:
        # Fallback: if no mappings, return all students in same school
        students = (
            db.query(Student)
            .filter(Student.school_id == teacher.school_id, Student.is_student == True)
            .all()
        )
    else:
        students = (
            db.query(Student)
            .filter(Student.section_ref_id.in_(section_ids), Student.is_student == True)
            .all()
        )

    return teacher, get_engagements_for_users(students, db, role_label="student")


def generate_alerts(summaries: list[StudentEngagementSummary]) -> list[EngagementAlert]:
    """Generate on-the-fly alerts from engagement summaries."""
    alerts: list[EngagementAlert] = []
    now_str = datetime.now(timezone.utc).isoformat()

    for i, s in enumerate(summaries):
        if s.engagement_status == EngagementStatus.ACTIVE:
            continue

        if s.engagement_status == EngagementStatus.AT_RISK:
            reason = f"{s.full_name} has only {s.sessions_this_week} sessions this week"
        elif s.engagement_status == EngagementStatus.LOW_ENGAGEMENT:
            reason = f"{s.full_name} has no sessions this week"
        else:
            days = s.days_since_login
            reason = f"{s.full_name} has not logged in for {days} days" if days else f"{s.full_name} has never logged in"

        alerts.append(EngagementAlert(
            id=i + 1,
            student_id=s.student_id,
            alert_type=s.engagement_status,
            reason=reason,
            days_inactive=s.days_since_login,
            sessions_this_week=s.sessions_this_week,
            is_resolved=False,
            created_at=now_str,
        ))

    return alerts


def count_sessions_for_school(school_id: int, db: Session, since: datetime) -> int:
    """Count total JWT login sessions for all users in a school since a date."""
    return (
        db.query(func.count(OutstandingToken.id))
        .join(Student, OutstandingToken.user_id == Student.id)
        .filter(Student.school_id == school_id, OutstandingToken.created_at >= since)
        .scalar()
    ) or 0
