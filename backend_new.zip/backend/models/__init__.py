from models.django_tables import (
    Student, School, Section, Classes, GapAnalysis,
    Exam, StudentResult, Subject, SubjectTeacherMapping,
    InterventionLog,
)
