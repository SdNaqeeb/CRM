"""
SQLAlchemy mirrors of existing Django tables (read-only).
Table names match Django's {app_label}_{model_name} convention.

CRM-owned tables (crm_ prefix) are read-write.
"""
from sqlalchemy import (
    Column, Integer, String, Boolean, DateTime, Date, Float, Text,
    ForeignKey, BigInteger,
)
from database import Base


class School(Base):
    __tablename__ = "Users_school"

    id = Column(BigInteger, primary_key=True)
    name = Column(String)
    code = Column(String)
    legacy_section = Column(String, nullable=True)


class Classes(Base):
    __tablename__ = "myapp_classes"

    id = Column(BigInteger, primary_key=True)
    class_name = Column(String)
    class_code = Column(String, nullable=True)


class Section(Base):
    __tablename__ = "Users_section"

    id = Column(BigInteger, primary_key=True)
    school_id = Column(BigInteger, ForeignKey("Users_school.id"))
    class_name_id = Column(BigInteger, ForeignKey("myapp_classes.id"))
    name = Column(String)


class Student(Base):
    __tablename__ = "Users_student"

    id = Column(BigInteger, primary_key=True)
    fullname = Column(String, nullable=True)
    roll_number = Column(String, nullable=True)
    phone_number = Column(String, nullable=True)
    username = Column(String, nullable=True)
    email = Column(String, nullable=True)
    school_id = Column(BigInteger, ForeignKey("Users_school.id"), nullable=True)
    class_name_id = Column(BigInteger, ForeignKey("myapp_classes.id"), nullable=True)
    section = Column(String, nullable=True)
    is_active = Column(Boolean, default=True)
    is_student = Column(Boolean, default=False)
    is_teacher = Column(Boolean, default=False)
    is_staff = Column(Boolean, default=False)
    is_superuser = Column(Boolean, default=False)
    payment_done = Column(Boolean, default=False)
    last_login = Column(DateTime, nullable=True)
    password = Column(String, nullable=True)
    google_sub = Column(String, nullable=True)
    section_ref_id = Column(BigInteger, ForeignKey("Users_section.id"), nullable=True)
    math_marks = Column(Float, nullable=True)
    trial_expiry_date = Column(Date, nullable=True)


class Subject(Base):
    __tablename__ = "myapp_subject"

    id = Column(BigInteger, primary_key=True)
    subject_name = Column(String, nullable=True)
    subject_code = Column(String, nullable=True)


class GapAnalysis(Base):
    __tablename__ = "myapp_gapanalysis"

    id = Column(BigInteger, primary_key=True)
    student_id = Column(BigInteger, ForeignKey("Users_student.id"), nullable=True)
    class_name = Column(String, nullable=True)
    subject = Column(String, nullable=True)
    chapter_number = Column(String, nullable=True)
    question_text = Column(Text, nullable=True)
    student_score = Column(Float, nullable=True)
    date = Column(DateTime, nullable=True)
    percentage = Column(Float, nullable=True)
    session_key = Column(String, nullable=True)
    student_answering_time = Column(Float, nullable=True)
    max_marks = Column(Float, nullable=True)
    difficult_level = Column(String, nullable=True)


class Exam(Base):
    __tablename__ = "Users_exam"

    id = Column(BigInteger, primary_key=True)
    name = Column(String, nullable=True)
    exam_type = Column(String, nullable=True)
    teacher_id = Column(BigInteger, ForeignKey("Users_student.id"), nullable=True)
    class_section_id = Column(BigInteger, ForeignKey("Users_section.id"), nullable=True)
    total_students = Column(Integer, nullable=True)
    average_score = Column(Float, nullable=True)
    created_at = Column(DateTime, nullable=True)


class StudentResult(Base):
    __tablename__ = "Users_studentresult"

    id = Column(BigInteger, primary_key=True)
    exam_id = Column(BigInteger, ForeignKey("Users_exam.id"), nullable=True)
    student_id = Column(BigInteger, ForeignKey("Users_student.id"), nullable=True)
    total_marks_obtained = Column(Float, nullable=True)
    total_max_marks = Column(Float, nullable=True)
    overall_percentage = Column(Float, nullable=True)
    grade = Column(String, nullable=True)


class SubjectTeacherMapping(Base):
    __tablename__ = "Users_subjectteachermapping"

    id = Column(BigInteger, primary_key=True)
    teacher_id = Column(BigInteger, ForeignKey("Users_student.id"), nullable=True)
    subject_id = Column(BigInteger, ForeignKey("myapp_subject.id"), nullable=True)
    section_id = Column(BigInteger, ForeignKey("Users_section.id"), nullable=True)


class OutstandingToken(Base):
    __tablename__ = "token_blacklist_outstandingtoken"

    id = Column(BigInteger, primary_key=True)
    user_id = Column(BigInteger, ForeignKey("Users_student.id"), nullable=True)
    jti = Column(String, nullable=False)
    token = Column(Text, nullable=False)
    created_at = Column(DateTime, nullable=True)
    expires_at = Column(DateTime, nullable=True)


class BlacklistedToken(Base):
    __tablename__ = "token_blacklist_blacklistedtoken"

    id = Column(BigInteger, primary_key=True)
    blacklisted_at = Column(DateTime, nullable=False)
    token_id = Column(BigInteger, ForeignKey("token_blacklist_outstandingtoken.id"), nullable=False)


class Homework(Base):
    __tablename__ = "myapp_homework"

    id = Column(BigInteger, primary_key=True)
    title = Column(String, nullable=True)
    description = Column(Text, nullable=True)
    teacher_id = Column(BigInteger, ForeignKey("Users_student.id"), nullable=True)
    due_date = Column(DateTime, nullable=True)
    date_assigned = Column(DateTime, nullable=True)
    school_id = Column(BigInteger, ForeignKey("Users_school.id"), nullable=True)
    homework_code = Column(String, nullable=True)


class HomeworkSubmission(Base):
    __tablename__ = "myapp_homeworksubmission"

    id = Column(BigInteger, primary_key=True)
    homework_id = Column(String, nullable=True)  # FK to homework_code
    student_name_id = Column(BigInteger, ForeignKey("Users_student.id"), nullable=True)
    submission_date = Column(DateTime, nullable=True)
    score = Column(Integer, nullable=True)
    max_possible_score = Column(Integer, nullable=True)
    percentage = Column(Float, nullable=True)
    grade = Column(String, nullable=True)
    feedback = Column(Text, nullable=True)


class ClassworkSubmission(Base):
    __tablename__ = "myapp_classworksubmission"

    id = Column(BigInteger, primary_key=True)
    teacher_name_id = Column(BigInteger, ForeignKey("Users_student.id"), nullable=True)
    class_code = Column(String, nullable=True)
    submission_date = Column(DateTime, nullable=True)
    assignment_type = Column(String, nullable=True)
    class_average_percentage = Column(Float, nullable=True)
    school_id = Column(BigInteger, ForeignKey("Users_school.id"), nullable=True)
    processing_timestamp = Column(DateTime, nullable=True)


# ── CRM-owned tables ──

class InterventionLog(Base):
    """Tracks alerts and challenges sent to inactive students.
    Prevents duplicate sends at the same day-milestone (3, 7, 14)."""
    __tablename__ = "crm_intervention_log"

    id = Column(BigInteger, primary_key=True, autoincrement=True)
    student_id = Column(BigInteger, ForeignKey("Users_student.id"), nullable=False)
    intervention_type = Column(String(20), nullable=False)       # 'alert' or 'challenge'
    day_milestone = Column(Integer, nullable=False)              # 3, 7, or 14
    days_inactive = Column(Integer, nullable=True)               # actual days at time of send
    whatsapp_success = Column(Boolean, default=False)
    phone_number = Column(String(15), nullable=True)
    detail = Column(Text, nullable=True)
    created_at = Column(DateTime, nullable=False)
    # tracks which login the intervention was for — if student logs in
    # and goes inactive again, last_login_at will differ, so we send again
    last_login_at = Column(DateTime, nullable=True)

class ApiRequestLog(models.Model):
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True, blank=True,
        on_delete=models.SET_NULL
    )
    path = models.CharField(max_length=255)          # API endpoint
    method = models.CharField(max_length=10)         # GET, POST, etc.
    status_code = models.IntegerField(null=True)     # response status
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    user_agent = models.TextField(null=True, blank=True)
    request_data = models.JSONField(null=True, blank=True)   # body or query params
    response_time_ms = models.FloatField(null=True, blank=True)
    timestamp = models.DateTimeField(default=now)

    def __str__(self):
        return f"{self.method} {self.path} by {self.user or 'Anonymous'}"
