"""
Daily cron job scheduler using APScheduler.

Runs the intervention check once per day at 8:00 AM IST (2:30 AM UTC).
Sends alerts + challenge notifications to students inactive for 3/7/14 days.

IMPORTANT: Gunicorn runs multiple workers (e.g., -w 3). Each worker starts
its own scheduler. We use a PostgreSQL advisory lock to ensure only ONE
worker actually executes the intervention job — the others skip.
"""
import logging
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from sqlalchemy import text

from database import SessionLocal
from services.intervention_service import run_intervention_check

logger = logging.getLogger(__name__)

scheduler = BackgroundScheduler()

# Unique lock ID for the intervention job (any arbitrary integer)
INTERVENTION_LOCK_ID = 777001


def _run_daily_intervention():
    """Wrapper that creates its own DB session for the scheduled job.
    Uses a PostgreSQL advisory lock to prevent multiple workers from
    running the same job simultaneously."""
    db = SessionLocal()
    try:
        # Try to acquire an exclusive advisory lock (non-blocking).
        # Only ONE worker across all Gunicorn processes will get this lock.
        # Others will get False and skip.
        got_lock = db.execute(
            text("SELECT pg_try_advisory_lock(:lock_id)"),
            {"lock_id": INTERVENTION_LOCK_ID},
        ).scalar()

        if not got_lock:
            logger.info("Another worker is already running the intervention job — skipping")
            return

        logger.info("Acquired intervention lock — starting job")
        summary = run_intervention_check(db)
        logger.info("Scheduled intervention job finished: %s", summary)

    except Exception as e:
        logger.error("Scheduled intervention job failed: %s", e, exc_info=True)
    finally:
        # Always release the advisory lock
        try:
            db.execute(
                text("SELECT pg_advisory_unlock(:lock_id)"),
                {"lock_id": INTERVENTION_LOCK_ID},
            )
        except Exception:
            pass
        db.close()


def start_scheduler():
    """Start the daily scheduler. Call this once at app startup."""
    # Run daily at 8:00 AM IST = 2:30 AM UTC
    scheduler.add_job(
        _run_daily_intervention,
        trigger=CronTrigger(hour=2, minute=30, timezone="UTC"),
        id="daily_intervention_check",
        name="Daily inactive student intervention check",
        replace_existing=True,
        max_instances=1,  # Never run more than 1 instance of this job
    )
    scheduler.start()
    logger.info("Scheduler started — intervention job runs daily at 8:00 AM IST")


def stop_scheduler():
    """Gracefully shut down the scheduler."""
    if scheduler.running:
        scheduler.shutdown(wait=False)
        logger.info("Scheduler stopped")
