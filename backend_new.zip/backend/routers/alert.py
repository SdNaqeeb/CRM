"""Send WhatsApp alert endpoints — fetches student phone and sends message."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, List

from database import get_db
from models.django_tables import Student
from services.whatsapp_service import send_whatsapp_message

router = APIRouter(prefix="/api/alerts", tags=["alerts"])


class SendAlertRequest(BaseModel):
    student_id: int
    message: str = ""


class BulkSendAlertRequest(BaseModel):
    student_ids: List[int]
    message: str = ""


class AlertResult(BaseModel):
    student_id: int
    student_name: str
    phone: Optional[str] = None
    success: bool
    detail: str


@router.post("/send", response_model=AlertResult)
def send_alert(req: SendAlertRequest, db: Session = Depends(get_db)):
    student = db.query(Student).filter(Student.id == req.student_id).first()
    if not student:
        raise HTTPException(status_code=404, detail=f"Student ID {req.student_id} not found")

    name = student.fullname or student.username or f"Student #{student.id}"
    result = send_whatsapp_message(student.phone_number, req.message, student_name=name)

    return AlertResult(
        student_id=student.id,
        student_name=name,
        phone=result.get("phone"),
        success=result.get("success", False),
        detail="Message sent" if result.get("success") else result.get("error", "Failed"),
    )


@router.post("/send-bulk", response_model=List[AlertResult])
def send_bulk_alert(req: BulkSendAlertRequest, db: Session = Depends(get_db)):
    results: List[AlertResult] = []

    students = db.query(Student).filter(Student.id.in_(req.student_ids)).all()
    student_map = {s.id: s for s in students}

    for sid in req.student_ids:
        student = student_map.get(sid)
        if not student:
            results.append(AlertResult(
                student_id=sid,
                student_name="Unknown",
                success=False,
                detail="Student not found",
            ))
            continue

        name = student.fullname or student.username or f"Student #{student.id}"
        result = send_whatsapp_message(student.phone_number, req.message, student_name=name)
        results.append(AlertResult(
            student_id=student.id,
            student_name=name,
            phone=result.get("phone"),
            success=result.get("success", False),
            detail="Message sent" if result.get("success") else result.get("error", "Failed"),
        ))

    return results
