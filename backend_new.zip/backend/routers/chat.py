"""Chat router – provides the /api/chat endpoint for the CRM chatbot."""

import logging
from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from typing import Optional, Any
from sqlalchemy.orm import Session

from database import get_db
from services.chat_service import process_chat_message

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/chat", tags=["chat"])


class ChatHistoryItem(BaseModel):
    sender: str
    text: str


class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=1000)
    role: str = Field(default="teacher")
    school_id: Optional[int] = None
    school_code: Optional[str] = None
    username: Optional[str] = None
    dashboard_data: Optional[dict[str, Any]] = None  # Pre-loaded from frontend
    chat_history: Optional[list[ChatHistoryItem]] = None
    # Improvement plan fields
    class_name: Optional[str] = None       # e.g. "6", "7", "8", "9"
    exam_type: Optional[str] = None        # e.g. "exam_mode", "internal_exam"
    timeline_days: Optional[int] = None    # custom timeline in days (default 14)


class ChatResponse(BaseModel):
    reply: str
    intent: Optional[str] = None


@router.post("", response_model=ChatResponse)
def chat(req: ChatRequest, db: Session = Depends(get_db)):
    """Process a natural-language chat message and return a CRM-aware response."""
    try:
        history = None
        if req.chat_history:
            history = [{"sender": h.sender, "text": h.text} for h in req.chat_history]

        reply = process_chat_message(
            message=req.message,
            role=req.role,
            school_id=req.school_id,
            school_code=req.school_code,
            username=req.username,
            db=db,
            dashboard_data=req.dashboard_data,
            chat_history=history,
            class_name=req.class_name,
            exam_type=req.exam_type,
            timeline_days=req.timeline_days,
        )
        return ChatResponse(reply=reply)
    except Exception as e:
        logger.exception(f"Chat error: {e}")
        return ChatResponse(
            reply="Sorry, I encountered an error processing your request. Please try again."
        )
