from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

import cache
from database import get_db
from models.django_tables import Student
from schemas.engagement import StudentEngagementSummary, EngagementAlert, EngagementStatus
from services.engagement_service import (
    get_all_student_engagements,
    get_teacher_section_students,
    generate_alerts,
    calculate_student_engagement,
)

router = APIRouter(prefix="/api/engagement", tags=["engagement"])


@router.get("/detect-at-risk/{school_id}", response_model=list[StudentEngagementSummary])
def detect_at_risk(school_id: int, db: Session = Depends(get_db)):
    cache_key = f"at_risk_school:{school_id}"
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    summaries = get_all_student_engagements(school_id, db)
    result = [
        s for s in summaries
        if s.engagement_status in (EngagementStatus.AT_RISK, EngagementStatus.LOW_ENGAGEMENT, EngagementStatus.INACTIVE)
    ]
    cache.put(cache_key, result)
    return result


@router.get("/detect-at-risk/teacher/{username}", response_model=list[StudentEngagementSummary])
def detect_at_risk_for_teacher(username: str, db: Session = Depends(get_db)):
    cache_key = f"at_risk_teacher:{username}"
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    _, summaries = get_teacher_section_students(username, db)
    result = [
        s for s in summaries
        if s.engagement_status in (EngagementStatus.AT_RISK, EngagementStatus.LOW_ENGAGEMENT, EngagementStatus.INACTIVE)
    ]
    cache.put(cache_key, result)
    return result


@router.get("/alerts/{school_id}", response_model=list[EngagementAlert])
def get_alerts(school_id: int, resolved: bool = Query(False), db: Session = Depends(get_db)):
    cache_key = f"alerts:{school_id}:{resolved}"
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    summaries = get_all_student_engagements(school_id, db)
    alerts = generate_alerts(summaries)
    result = [] if resolved else alerts
    cache.put(cache_key, result)
    return result


@router.post("/alerts/{alert_id}/resolve")
def resolve_alert(alert_id: int):
    return {"status": "success", "alert_id": alert_id, "resolved": True}


@router.get("/status/{student_id}", response_model=StudentEngagementSummary)
def get_student_status(student_id: int, db: Session = Depends(get_db)):
    cache_key = f"status:{student_id}"
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    student = db.query(Student).filter(Student.id == student_id).first()
    if not student:
        return StudentEngagementSummary(
            student_id=student_id,
            user_id=student_id,
            full_name="Unknown",
            engagement_status=EngagementStatus.INACTIVE,
        )
    result = calculate_student_engagement(student, db)
    cache.put(cache_key, result)
    return result
