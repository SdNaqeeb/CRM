from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

import cache
from database import get_db
from models.django_tables import Student, School, GapAnalysis, StudentResult, Classes
from schemas.dashboard import (
    TeacherDashboardData, SchoolDashboardData,
    OrcaLexDashboardData, OrcaLexSchoolSummary,
)
from schemas.engagement import EngagementStatus, StudentEngagementSummary
from services.engagement_service import (
    get_all_student_engagements,
    get_all_teacher_engagements,
    get_teacher_section_students,
    get_google_auth_users,
    generate_alerts,
    count_sessions_for_school,
    calculate_student_engagement,
    _week_start,
    _last_week_start,
)

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])


def _count_statuses(summaries: list[StudentEngagementSummary]):
    active = sum(1 for s in summaries if s.engagement_status == EngagementStatus.ACTIVE)
    active_sessions = sum(1 for s in summaries if s.is_currently_active)
    at_risk = sum(1 for s in summaries if s.engagement_status == EngagementStatus.AT_RISK)
    low = sum(1 for s in summaries if s.engagement_status == EngagementStatus.LOW_ENGAGEMENT)
    inactive = sum(1 for s in summaries if s.engagement_status == EngagementStatus.INACTIVE)
    return active, active_sessions, at_risk, low, inactive


# ─── Teacher dashboard: students from mapped sections ───
@router.get("/teacher/by-username/{username}", response_model=TeacherDashboardData)
def get_teacher_dashboard_by_username(username: str, db: Session = Depends(get_db)):
    cache_key = f"teacher_username:{username}"
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    teacher, summaries = get_teacher_section_students(username, db)
    if not teacher:
        raise HTTPException(status_code=404, detail=f"Teacher '{username}' not found")

    alerts = generate_alerts(summaries)
    active, active_sessions, at_risk, low, inactive = _count_statuses(summaries)

    result = TeacherDashboardData(
        total_students=len(summaries),
        active_students=active,
        active_sessions=active_sessions,
        at_risk_students=at_risk,
        low_engagement_students=low,
        inactive_students=inactive,
        students=summaries,
        recent_alerts=alerts[:20],
        teacher_name=teacher.fullname or teacher.username or "",
        teacher_id=teacher.id,
    )
    cache.put(cache_key, result)
    return result


# ─── Legacy teacher endpoint (by school_id) ───
@router.get("/teacher/{school_id}", response_model=TeacherDashboardData)
def get_teacher_dashboard(school_id: int, db: Session = Depends(get_db)):
    cache_key = f"teacher_school:{school_id}"
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    summaries = get_all_student_engagements(school_id, db)
    alerts = generate_alerts(summaries)
    active, active_sessions, at_risk, low, inactive = _count_statuses(summaries)

    result = TeacherDashboardData(
        total_students=len(summaries),
        active_students=active,
        active_sessions=active_sessions,
        at_risk_students=at_risk,
        low_engagement_students=low,
        inactive_students=inactive,
        students=summaries,
        recent_alerts=alerts[:20],
    )
    cache.put(cache_key, result)
    return result


# ─── School Admin dashboard by school_code ───
@router.get("/school/by-code/{school_code}", response_model=SchoolDashboardData)
def get_school_dashboard_by_code(school_code: str, db: Session = Depends(get_db)):
    cache_key = f"school_code:{school_code}"
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    school = db.query(School).filter(School.code == school_code).first()
    if not school:
        raise HTTPException(status_code=404, detail=f"School with code '{school_code}' not found")

    # Delegate to the existing school_id-based logic
    result = _build_school_dashboard(school, db)
    cache.put(cache_key, result)
    return result


def _build_school_dashboard(school, db: Session) -> SchoolDashboardData:
    """Shared logic for building school dashboard data from a School ORM object."""
    student_summaries = get_all_student_engagements(school.id, db)
    teacher_summaries = get_all_teacher_engagements(school.id, db)
    all_summaries = student_summaries + teacher_summaries
    alerts = generate_alerts(all_summaries)

    active, active_sessions, at_risk, low, inactive = _count_statuses(all_summaries)

    week_start = _week_start()
    last_week_start = _last_week_start()

    sessions_this_week = count_sessions_for_school(school.id, db, week_start)
    sessions_last_week = count_sessions_for_school(school.id, db, last_week_start) - sessions_this_week

    if sessions_last_week <= 0:
        trend = "up" if sessions_this_week > 0 else "stable"
    elif sessions_this_week > sessions_last_week:
        trend = "up"
    elif sessions_this_week < sessions_last_week:
        trend = "down"
    else:
        trend = "stable"

    return SchoolDashboardData(
        school_id=school.id,
        school_name=school.name or "Unknown",
        total_students=len(all_summaries),
        active_this_week=active,
        active_sessions=active_sessions,
        at_risk_count=at_risk,
        inactive_count=inactive,
        total_sessions_this_week=sessions_this_week,
        engagement_trend=trend,
        students=student_summaries,
        teachers=teacher_summaries,
        recent_alerts=alerts[:20],
    )


# ─── School Admin dashboard: all students + teachers in one school ───
@router.get("/school/{school_id}", response_model=SchoolDashboardData)
def get_school_dashboard(school_id: int, db: Session = Depends(get_db)):
    cache_key = f"school:{school_id}"
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    school = db.query(School).filter(School.id == school_id).first()
    if not school:
        raise HTTPException(status_code=404, detail=f"School with ID {school_id} not found")

    result = _build_school_dashboard(school, db)
    cache.put(cache_key, result)
    return result


# ─── OrcaLex Admin: all schools, all students, all teachers ───
@router.get("/orcalex/all", response_model=OrcaLexDashboardData)
def get_orcalex_dashboard(db: Session = Depends(get_db)):
    cache_key = "orcalex:all"
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    schools = db.query(School).all()

    all_students: list[StudentEngagementSummary] = []
    all_teachers: list[StudentEngagementSummary] = []
    school_summaries: list[OrcaLexSchoolSummary] = []
    total_sessions_all = 0

    week_start = _week_start()
    last_week_start = _last_week_start()

    for school in schools:
        s_summaries = get_all_student_engagements(school.id, db)
        t_summaries = get_all_teacher_engagements(school.id, db)
        # Tag each summary with school_id
        for s in s_summaries:
            s.school_id = school.id
        for t in t_summaries:
            t.school_id = school.id
        combined = s_summaries + t_summaries
        active, active_sess, at_risk, low, inactive = _count_statuses(combined)

        sessions_this_week = count_sessions_for_school(school.id, db, week_start)
        sessions_last_week = count_sessions_for_school(school.id, db, last_week_start) - sessions_this_week

        if sessions_last_week <= 0:
            trend = "up" if sessions_this_week > 0 else "stable"
        elif sessions_this_week > sessions_last_week:
            trend = "up"
        elif sessions_this_week < sessions_last_week:
            trend = "down"
        else:
            trend = "stable"

        total_sessions_all += sessions_this_week

        school_summaries.append(OrcaLexSchoolSummary(
            school_id=school.id,
            school_name=school.name,
            total_students=len(s_summaries),
            total_teachers=len(t_summaries),
            active_this_week=active,
            active_sessions=active_sess,
            at_risk_count=at_risk,
            inactive_count=inactive,
            total_sessions_this_week=sessions_this_week,
            engagement_trend=trend,
        ))

        all_students.extend(s_summaries)
        all_teachers.extend(t_summaries)

    # Include Google-authenticated users (no school assigned)
    google_users = get_google_auth_users(db)
    if google_users:
        g_active, g_active_sess, g_at_risk, g_low, g_inactive = _count_statuses(google_users)
        school_summaries.append(OrcaLexSchoolSummary(
            school_id=0,
            school_name="Google Auth Users (No School)",
            total_students=len(google_users),
            total_teachers=0,
            active_this_week=g_active,
            active_sessions=g_active_sess,
            at_risk_count=g_at_risk,
            inactive_count=g_inactive,
            total_sessions_this_week=0,
            engagement_trend="stable",
        ))
        all_students.extend(google_users)

    all_combined = all_students + all_teachers
    total_active, total_active_sessions, total_at_risk, _, total_inactive = _count_statuses(all_combined)
    alerts = generate_alerts(all_combined)

    result = OrcaLexDashboardData(
        total_schools=len(schools),
        total_students=len(all_students),
        total_teachers=len(all_teachers),
        active_this_week=total_active,
        active_sessions=total_active_sessions,
        at_risk_count=total_at_risk,
        inactive_count=total_inactive,
        total_sessions_this_week=total_sessions_all,
        schools=school_summaries,
        all_students=all_students,
        all_teachers=all_teachers,
        recent_alerts=alerts[:30],
    )
    cache.put(cache_key, result)
    return result


# ─── Single student detail ───
@router.get("/student-summary/{student_id}")
def get_student_summary(student_id: int, db: Session = Depends(get_db)):
    cache_key = f"student_summary:{student_id}"
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    student = db.query(Student).filter(Student.id == student_id).first()
    if not student:
        return {"error": "Student not found"}

    summary = calculate_student_engagement(student, db)

    recent_ga = (
        db.query(GapAnalysis)
        .filter(GapAnalysis.student_id == student_id)
        .order_by(GapAnalysis.date.desc())
        .limit(10)
        .all()
    )
    gap_entries = [
        {
            "id": g.id,
            "subject": g.subject,
            "chapter_number": g.chapter_number,
            "student_score": g.student_score,
            "max_marks": g.max_marks,
            "percentage": g.percentage,
            "date": g.date.isoformat() if g.date else None,
        }
        for g in recent_ga
    ]

    results = (
        db.query(StudentResult)
        .filter(StudentResult.student_id == student_id)
        .all()
    )
    exam_results = [
        {
            "id": r.id,
            "exam_id": r.exam_id,
            "total_marks_obtained": r.total_marks_obtained,
            "total_max_marks": r.total_max_marks,
            "overall_percentage": r.overall_percentage,
            "grade": r.grade,
        }
        for r in results
    ]

    result = {
        **summary.model_dump(),
        "recent_gap_analysis": gap_entries,
        "exam_results": exam_results,
    }
    cache.put(cache_key, result)
    return result
