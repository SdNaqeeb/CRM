"""Activity endpoints — student and teacher activity from real DB tables."""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

import cache
from database import get_db
from schemas.activity import ActivityOverview, UserActivityTimeline
from services.activity_service import (
    get_daily_activity_for_school,
    get_student_activity_entries,
    get_teacher_activity_entries,
)
from models.django_tables import Student

router = APIRouter(prefix="/api/activity", tags=["activity"])


@router.get("/school/{school_id}", response_model=ActivityOverview)
def get_school_activity(
    school_id: int,
    days: int = Query(14, ge=1, le=90),
    db: Session = Depends(get_db),
):
    cache_key = f"activity:school:{school_id}:{days}"
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    result = get_daily_activity_for_school(school_id, db, days=days)
    cache.put(cache_key, result)
    return result


@router.get("/student/{student_id}", response_model=UserActivityTimeline)
def get_student_activity(
    student_id: int,
    days: int = Query(30, ge=1, le=90),
    db: Session = Depends(get_db),
):
    cache_key = f"activity:student:{student_id}:{days}"
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    student = db.query(Student).filter(Student.id == student_id).first()
    entries = get_student_activity_entries(student_id, db, days=days)
    result = UserActivityTimeline(
        user_id=student_id,
        user_name=student.fullname or "" if student else "",
        role="student",
        total_activities=len(entries),
        activities=entries,
    )
    cache.put(cache_key, result)
    return result


@router.get("/teacher/{teacher_id}", response_model=UserActivityTimeline)
def get_teacher_activity(
    teacher_id: int,
    days: int = Query(30, ge=1, le=90),
    db: Session = Depends(get_db),
):
    cache_key = f"activity:teacher:{teacher_id}:{days}"
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    teacher = db.query(Student).filter(Student.id == teacher_id).first()
    entries = get_teacher_activity_entries(teacher_id, db, days=days)
    result = UserActivityTimeline(
        user_id=teacher_id,
        user_name=teacher.fullname or "" if teacher else "",
        role="teacher",
        total_activities=len(entries),
        activities=entries,
    )
    cache.put(cache_key, result)
    return result
