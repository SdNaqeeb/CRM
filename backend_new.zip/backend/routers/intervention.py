"""Intervention endpoints — manual trigger + history."""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from database import get_db
from services.intervention_service import run_intervention_check

router = APIRouter(prefix="/api/interventions", tags=["interventions"])


@router.post("/run-now")
def trigger_intervention_now(db: Session = Depends(get_db)):
    """Manual trigger — run the intervention check immediately.
    Useful for testing or on-demand runs."""
    summary = run_intervention_check(db)
    return summary
