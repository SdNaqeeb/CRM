"""Stub endpoints for challenges – returns empty/success so the frontend doesn't break."""
from datetime import datetime
from fastapi import APIRouter, HTTPException, Query
from schemas.challenge import (
    SendChallengeRequest,
    BulkSendChallengeRequest,
    CompleteChallengeRequest,
    MCQChallenge,
    GeneratePreviewRequest,
    GeneratePreviewResponse,
    MCQQuestion,
    MCQOption,
)
from services.ai_service import generate_mcq_questions

router = APIRouter(prefix="/api/challenges", tags=["challenges"])

_next_id = 1


def _make_challenge(student_id: int, subject: str, concept: str | None, num_questions: int = 5) -> MCQChallenge:
    global _next_id
    c = MCQChallenge(
        id=_next_id,
        student_id=student_id,
        title=f"{subject} Challenge",
        subject=subject,
        concept=concept,
        total_questions=num_questions,
        sent_at=datetime.utcnow().isoformat(),
        notification_sent=True,
    )
    _next_id += 1
    return c


@router.post("/generate-preview", response_model=GeneratePreviewResponse)
def generate_preview(req: GeneratePreviewRequest):
    try:
        raw_questions = generate_mcq_questions(
            subject=req.subject,
            grade=req.grade,
            num_questions=req.num_questions,
            concept=req.concept,
        )
        questions = [
            MCQQuestion(
                question=q["question"],
                options=[MCQOption(label=o["label"], text=o["text"]) for o in q["options"]],
                correct_answer=q["correct_answer"],
                explanation=q["explanation"],
            )
            for q in raw_questions
        ]
        return GeneratePreviewResponse(questions=questions)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to generate questions: {str(e)}")


@router.post("/send-manual", response_model=MCQChallenge)
def send_manual_challenge(req: SendChallengeRequest):
    return _make_challenge(req.student_id, req.subject, req.concept, req.num_questions)


@router.post("/send-bulk", response_model=list[MCQChallenge])
def send_bulk_challenge(req: BulkSendChallengeRequest):
    return [_make_challenge(sid, req.subject, req.concept) for sid in req.student_ids]


@router.get("/student/{student_id}", response_model=list[MCQChallenge])
def get_student_challenges(student_id: int, pending_only: bool = Query(False)):
    return []


@router.post("/complete")
def complete_challenge(req: CompleteChallengeRequest):
    return {"status": "success", "challenge_id": req.challenge_id, "score": req.score}
