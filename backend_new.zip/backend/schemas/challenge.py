from pydantic import BaseModel
from typing import Optional, List


class SendChallengeRequest(BaseModel):
    student_id: int
    subject: str
    concept: Optional[str] = None
    num_questions: int = 5


class BulkSendChallengeRequest(BaseModel):
    student_ids: List[int]
    subject: str
    concept: Optional[str] = None


class CompleteChallengeRequest(BaseModel):
    challenge_id: int
    score: float
    time_taken_seconds: int


class MCQChallenge(BaseModel):
    id: int
    student_id: int
    title: str
    subject: Optional[str] = None
    concept: Optional[str] = None
    total_questions: int = 5
    sent_at: str
    completed_at: Optional[str] = None
    score: Optional[float] = None
    notification_sent: bool = False


class GeneratePreviewRequest(BaseModel):
    subject: str
    grade: str
    num_questions: int = 5
    concept: Optional[str] = None


class MCQOption(BaseModel):
    label: str
    text: str


class MCQQuestion(BaseModel):
    question: str
    options: List[MCQOption]
    correct_answer: str
    explanation: str


class GeneratePreviewResponse(BaseModel):
    questions: List[MCQQuestion]
