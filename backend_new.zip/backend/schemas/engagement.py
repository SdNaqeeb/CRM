from pydantic import BaseModel
from typing import Optional
from enum import Enum


class EngagementStatus(str, Enum):
    ACTIVE = "active"
    AT_RISK = "at_risk"
    LOW_ENGAGEMENT = "low_engagement"
    INACTIVE = "inactive"


class StudentEngagementSummary(BaseModel):
    student_id: int
    user_id: int
    full_name: str
    email: Optional[str] = None
    grade: Optional[str] = None
    section: Optional[str] = None
    last_login: Optional[str] = None
    days_since_login: Optional[int] = None
    total_sessions: int = 0
    sessions_this_week: int = 0
    engagement_status: EngagementStatus = EngagementStatus.INACTIVE
    has_active_alert: bool = False
    is_currently_active: bool = False
    auth_provider: str = "password"
    role: str = "student"
    school_id: Optional[int] = None


class EngagementAlert(BaseModel):
    id: int
    student_id: int
    alert_type: EngagementStatus
    reason: str
    days_inactive: Optional[int] = None
    sessions_this_week: Optional[int] = None
    is_resolved: bool = False
    created_at: str
