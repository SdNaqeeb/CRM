from pydantic import BaseModel
from typing import List, Literal
from schemas.engagement import StudentEngagementSummary, EngagementAlert


class TeacherDashboardData(BaseModel):
    total_students: int = 0
    active_students: int = 0
    active_sessions: int = 0
    at_risk_students: int = 0
    low_engagement_students: int = 0
    inactive_students: int = 0
    students: List[StudentEngagementSummary] = []
    recent_alerts: List[EngagementAlert] = []
    teacher_name: str = ""
    teacher_id: int = 0


class SchoolDashboardData(BaseModel):
    school_id: int = 0
    school_name: str = ""
    total_students: int = 0
    active_this_week: int = 0
    active_sessions: int = 0
    at_risk_count: int = 0
    inactive_count: int = 0
    total_sessions_this_week: int = 0
    engagement_trend: Literal["up", "down", "stable"] = "stable"
    students: List[StudentEngagementSummary] = []
    teachers: List[StudentEngagementSummary] = []
    recent_alerts: List[EngagementAlert] = []


class OrcaLexSchoolSummary(BaseModel):
    school_id: int
    school_name: str = ""
    total_students: int = 0
    total_teachers: int = 0
    active_this_week: int = 0
    active_sessions: int = 0
    at_risk_count: int = 0
    inactive_count: int = 0
    total_sessions_this_week: int = 0
    engagement_trend: Literal["up", "down", "stable"] = "stable"


class OrcaLexDashboardData(BaseModel):
    total_schools: int = 0
    total_students: int = 0
    total_teachers: int = 0
    active_this_week: int = 0
    active_sessions: int = 0
    at_risk_count: int = 0
    inactive_count: int = 0
    total_sessions_this_week: int = 0
    schools: List[OrcaLexSchoolSummary] = []
    all_students: List[StudentEngagementSummary] = []
    all_teachers: List[StudentEngagementSummary] = []
    recent_alerts: List[EngagementAlert] = []
