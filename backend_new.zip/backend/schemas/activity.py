from pydantic import BaseModel
from typing import Optional


class ActivityEntry(BaseModel):
    id: int
    user_id: int
    user_name: str = ""
    activity_type: str  # "gap_analysis", "homework_submission", "exam_created", "classwork", "exam_result"
    title: str = ""
    subject: Optional[str] = None
    score: Optional[float] = None
    max_score: Optional[float] = None
    percentage: Optional[float] = None
    timestamp: str
    role: str = "student"  # "student" or "teacher"


class DailyActivitySummary(BaseModel):
    date: str
    total_submissions: int = 0
    student_submissions: int = 0
    teacher_activities: int = 0
    entries: list[ActivityEntry] = []


class UserActivityTimeline(BaseModel):
    user_id: int
    user_name: str = ""
    role: str = "student"
    total_activities: int = 0
    activities: list[ActivityEntry] = []


class ActivityOverview(BaseModel):
    total_student_submissions: int = 0
    total_teacher_activities: int = 0
    total_gap_analysis: int = 0
    total_homework_submissions: int = 0
    total_exams_created: int = 0
    total_classwork: int = 0
    daily_breakdown: list[DailyActivitySummary] = []
