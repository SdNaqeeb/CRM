import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

import cache
from database import engine, Base
from routers import dashboard, engagement, challenge, activity, alert
from routers import intervention, chat
from scheduler import start_scheduler, stop_scheduler

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    # --- Startup ---
    # Create CRM-owned tables (crm_ prefix) if they don't exist yet
    from models.django_tables import InterventionLog  # noqa: F401
    Base.metadata.create_all(bind=engine, tables=[InterventionLog.__table__])
    logger.info("CRM tables ensured in database")

    # Start the daily intervention scheduler
    start_scheduler()
    logger.info("Application startup complete")

    yield

    # --- Shutdown ---
    stop_scheduler()
    logger.info("Application shutdown complete")


app = FastAPI(title="SmartLearners CRM Backend", version="1.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://localhost:3001",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:3001",
        "https://crm.smartlearners.ai",
        "https://crmapi.smartlearners.ai",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(dashboard.router)
app.include_router(engagement.router)
app.include_router(challenge.router)
app.include_router(activity.router)
app.include_router(alert.router)
app.include_router(intervention.router)
app.include_router(chat.router)


@app.get("/")
def root():
    return {"status": "ok", "service": "SmartLearners CRM Backend"}


@app.get("/health")
def health():
    return {"status": "healthy", "cache_ttl_seconds": cache.CACHE_TTL_SECONDS}


@app.post("/api/cache/clear")
def clear_cache():
    cache.invalidate()
    return {"status": "cleared"}
