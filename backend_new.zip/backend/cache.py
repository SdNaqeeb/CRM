"""
Simple in-memory TTL cache for API responses.
Stores serialised Pydantic models / dicts keyed by (endpoint, params).
Default TTL: 5 minutes.
"""
import time
import threading

CACHE_TTL_SECONDS = 30 * 60  # 30 minutes

_store: dict[str, tuple[float, object]] = {}
_lock = threading.Lock()


def get(key: str):
    """Return cached value if it exists and hasn't expired, else None."""
    with _lock:
        entry = _store.get(key)
        if entry is None:
            return None
        expires_at, value = entry
        if time.monotonic() > expires_at:
            del _store[key]
            return None
        return value


def put(key: str, value: object):
    """Store a value with the default TTL."""
    with _lock:
        _store[key] = (time.monotonic() + CACHE_TTL_SECONDS, value)


def invalidate(prefix: str = ""):
    """Remove all keys that start with prefix. Empty prefix clears everything."""
    with _lock:
        if not prefix:
            _store.clear()
        else:
            keys = [k for k in _store if k.startswith(prefix)]
            for k in keys:
                del _store[k]
